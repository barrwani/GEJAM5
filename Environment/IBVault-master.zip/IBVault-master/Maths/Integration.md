# Integration
#maths 

Integration is the reversed process of [[Differentiation]]. 

## Basic Integration Rules

![|300](https://www.onlinemathlearning.com/image-files/integral-rules.png)


## Standard Integrals
```ad-note 
title: Standard Integrals
icon: calculator
color: 66, 87,80
$$\int \frac 1x dx = \ln (|x|) + C$$
$$\int \sin (x) dx = - \cos x + C$$
$$\int \cos (x) dx = \sin x + C$$
$$\int e^x = e^x + C$$
$$\int 	\frac1{\sqrt{1-x^2}}dx = \arcsin x + C$$
$$\int 	\frac1{1+x^2}dx = \arctan x + C$$
$$\int a^x dx = \frac 1{\ln a}a^x + C$$
```

## Reverse Chain Rule
The Reverse Chain Rule Equation is as follows:
$$\int f(ax+b) dx = \frac1{a}F(ax+b) + C$$
Where F(x) is the integral of f(x).

This only applies when the inside of the function is in the form (ax+b). A common example would be $\int \cos (4x) dx$.

## By Parts
The equation for Integration by Parts is as follows:
```ad-note
title:Equation
icon: calculator
color: 66,87,80
$$\int udv = uv - \int vdu$$
```


If you get stuck in a loop, you can assign your original integral to a **variable** and solve for it. 

Example:

$$I = \int e^x \cos (x) dx$$
$$= e^x \cos x - \int e^x \sin (x) dx $$
$$= e^x \cos x - (-e^x \sin x  - \int e^x \cos (x) dx)$$
$$ = e^x \cos x + e^x \sin x - I$$
$$I = \frac 12 (e^x \cos x + e^x \sin x) $$

This can be done for any integrals which loop back to the original integral.

You might have also chosen the wrong values for u and dv:

![](https://external-preview.redd.it/oxMzHxvEZH7p_IzKfX3LFjbIvSsS9N22sytOMGC_f3c.png?auto=webp&s=5b1bd3f75322fa6b286d23b57433d590c68b8d7c)

## By Substitution

In Integration by substitution, you would 

1. Substitute part of the equation for u

2. Find dx by rearranging [$\frac{du}{dx} = ...$ ] for dx.

3. Typically in substitution it will cancel out the remaining values of x so you can integrate with respect to u. 

	- If it doesn't cancel out, you would substitute again. If you chose the wrong value to substitute you will end up in a loop.

4. You would then substitute x back in.

## Area of region enclosed by a curve
Definite Integration involving parameters is used to find the area enclosed by a curve. 

When finding the area, always try to sketch the graph in order to see which parts are negative and which are positive. 

This way, you will be able to separate the parameters and find the areas without them negating each other.

![[Pasted image 20211218132809.png|245]]  ![[Pasted image 20211218132823.png|250]]

By finding the absolute value of the equation, we can ensure that our areas don't negate each other.

When finding the area enclosed by the y axis, we treat x as a function of y ($x = f(y)$)
![[Pasted image 20211218133213.png|250]] ![[Pasted image 20211218133142.png|230]]
Then solve as normal.

To find the area between two curves, we find $\int |f(x) - g(x)| dx$. We think of our lower curve g$(x)$ as the bound axis (when using the axis itself it would be $f(x) - 0$.
![[Pasted image 20211218133627.png|250]]

## Volume of Revolution
The volume of revolution of a given curve relates to the volume of the object produced when the area bound by the curve is rotated around a given axis.

The volume of revolution around the x-axis is given by:
$$\int_{x=a}^{x=b} \pi y^2 dx$$

The volume of revolution around the y-axis is given by:
$$\int_{y=c}^{y=d} \pi x^2 dy$$

```ad-note
title: NOTE
color: 66, 87, 80
When given a question involving the volume of revolution, you will be told the degree of rotation in either degrees or radians.

If the degree is 360 degrees or $2 \pi$, you would use the formula as given above. 

Otherwise, you would divide it by whatever fraction of a full rotation it is given by.

EG:
Given a degree of 180 degrees:

$$\frac 12 \int \pi y^2 dx \equiv\frac{\pi}2  \int y^2 dx$$

```

