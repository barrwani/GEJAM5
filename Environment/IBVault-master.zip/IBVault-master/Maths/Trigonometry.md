# Trigonometry
#maths 

## Special Angles & Unit Circle

Memorise the special triangles and use them with SOHCAHTOA to find the special angles.

![|350](https://www.onlinemathlearning.com/image-files/trigonometric-ratios-special-angles.png)

When an angle ratio is given, use the unit circle to find out whether the resulting angle is positive or negative. 

If not given a special angle, use the Compound Angle Identity to find the value. 


![|350](https://cdn-academy.pressidium.com/academy/wp-content/uploads/2021/03/Unit-circle.png)

Sine and Cosine can produce the same values for different angles. The relationship between angles is shown above.


![|420](http://intomath.org/wp-content/uploads/2021/03/CAST-Rule-1024x576.jpg)

## Trig Graph Transformations
Several different transformations may occur to a trigonometric graph. 

```ad-note
title: Transformed Trig Function
icon: calculator
color:66,87,80
$$y = a\sin(bx-c) + d$$
```

From the above equation we have 4 different transformation parameters:

- Amplitude = **a**

- Period = $\frac{2\pi}{b}$

- Horizontal Shift = **c**

- Vertical Shift = **d**

![](https://i.ytimg.com/vi/AS7THLj-OhI/maxresdefault.jpg)

The parameters apply to** both sine and cosine**. 

## Triangles

A few important things to know about triangles.

![[Pasted image 20211216130214.png|350]]

The Cosine Rule is used when given 3 sides and one angle, including the unknown. 

```ad-note
title: Cosine Rule
color: 66,87,80
icon: calculator
Find Side:
$$c^2 = a^2 + b^2 - 2ab\cos C$$
Find Angle:
$$\cos C   = \frac{a^2 + b^2 - c^2}{2ab}
```

The Sine Rule is used when given 2 angles and 2 sides, including the unknown.

```ad-note
title: Sine Rule
color: 66,87, 80
icon: calculator
Find Side:
$$\frac{a}{\sin A} =\frac{b}{\sin B} =\frac{c}{\sin C} $$

Find Angle:
$$\frac{\sin A}{a} = \frac{\sin B}{b} = \frac{\sin C}{c}$$
```


## Circles & Radians

A full circle is 360 degrees. It's also $2 \pi$ radians. 

When making any calculations to do with arcs, use radians instead of degrees.

Common Conversions:
- 360 degrees = $2\pi$ rad

- 180 degrees = $\pi$ rad

- 90 degrees = $\frac{\pi}{2}$ rad

- 60 degrees = $\frac{\pi}{3}$ rad

- 45 degrees = $\frac{\pi}{4}$ rad

- 36 degrees = $\frac{\pi}{5}$ rad

- 30 degrees = $\frac{\pi}{6}$ rad

- 15 degrees = $\frac{\pi}{12}$ rad

```ad-note
title: Arc Equations
icon: calculator
color:66,87,80
Arc Length: $$ l = r\theta $$
Area of a Sector: $$A = \frac 12 \theta r^2$$
```

## Trigonometric Identities

Trig Identities are equalities involve trigonometric functions and always prove true for every value. 

Common:
```ad-note
title: Basic Identities
icon: calculator
color: 66,87,80
Tan Identity: $$\tan \theta = \frac{\sin \theta}{\cos \theta} $$
Reciprocal Identities:

$$\sec \theta = \frac1{\cos \theta}$$
$$\csc \theta = \frac1{\sin \theta}$$
$$\cot \theta = \frac1{\tan \theta}$$
```

The most important identities:
```ad-note
title: Pythagorean Identities
color: 66,87,80
Basic:
$$\cos^2\theta + \sin^2\theta = 1$$
Reciprocal:
$$1 + \tan^2\theta = \sec^2\theta$$

$$1 + \cot^2\theta = \csc^2\theta$$
```

Heavily Used:
```ad-note
title: Double Angle Identities
icon: calculator
color: 66,87,80

$$\sin2\theta = 2sin\theta\cos
\theta$$
$$\cos2\theta = \cos^2\theta - \sin^2\theta = 2\cos^2\theta - 1 = 1-2\sin^2\theta$$
$$\tan2\theta = \frac{2\tan\theta}{1-\tan^2\theta} $$
```

Can be used to break down non-special angles into special angles:

```ad-note
title: Compound Angle Identities
icon: calculator
color: 66,87,80
$$\sin(A\pm B) = \sin A \cos B \pm \cos A \sin B$$
$$\cos(A \pm B) = \cos A \cos B \mp \sin A \sin B $$
$$\tan (A \pm B) = \frac{\tan A \pm \tan B}{1 \mp \tan A \tan B}$$
```

## Arcus Functions

Arcus (Inverse) Trigonometric Functions are the inverse operation of regular trigonometric functions. 

Applying these functions to the trig ratios (SOHCAHTOA) produces the angle formed by the sides. 

```ad-note
title: Arcus Functions
icon: calculator
color: 66,87,80

$$\arcsin x = \sin ^{-1}(x)$$
$$\arccos x = \cos ^{-1}(x)$$
$$\arctan x = \tan ^{-1}(x)$$

```

Arcus Functions have a domain of [-1, 1]. They cannot produce values greater than 90 or less than -90. 