# Exponents and Logarithms
#maths 

## Laws of Exponents
```ad-note
title:Laws
icon:calculator
color:67,86,80
$$a^m \times a^n = a^{m+n}$$
$$a^m \div a^n = a^{m-n}$$
$$(a^m)^n = a^{mn}$$
$$a^n \times b^n = (ab)^n$$
$$a^n \div b^n = (\frac ab)^n$$
```

## Laws of Logarithms
```ad-note
icon:calculator
title:Laws
color: 67,86,80
$$\log_am + \log_an = \log_amn$$
$$\log_am - \log_an = \log_a \frac mn$$
$$log_am^n = nlog_am$$
$$log_a1 = 0$$
$$log_aa = 1$$
$$a^{\log_ax} = x$$
$$log_ax = \frac{log_bx}{log_ba}$$
```