# Functions
#maths 


## What is a function?
A function is a graph which meets the vertical line condition.

The vertical line condition states that one x value can only produce one y value. 
You check this using the vertical line test, simply drawing vertical lines across the graph. 

If any one line touches the graph more than once, it is not a function.

There are two kinds of function, one-to-one and many-to-one. You can distinguish between them using the horizontal line test.

- A function is one-to-one if no horizontal line touches the graph more than once. 

- It is many-to-one if any horizontal line touches the graph more than once. 


## Notation
Functions can be written in a few different ways:

$f(x) =...$ 
or
$f:x \to...$

We input values into our function $f(x)$ and receive an output. 
Example:

$f(x) = 3x+5$ so $f(1) = 8$

You can view $f(x)$ to be $y$.
## Domain & Range
The set of allowed **input** values is called the **domain** of the function. 
We write it after the function either as a series of inequalities, using set notation or interval notation.

The set of all possible **outputs** of a function is called the **range**. The easiest way of finding this is to sketch the graph. 

The range relies on the domain. 

## Composite Functions
We can apply one function to a number and then apply another function to that result. 
The result is called a composite function.

If we apply the function g to x, then apply the function f to g, we can write it as:
$f(g(x))$
$fg(x)$ 
$f \circ g(x)$

The range of $g(x)$ must lie within the range of $f(x)$.

## Inverse Functions
An Inverse Function reverses the operation of the function. It is typically noted as $f^{-1}(x)$ 
To find the inverse function:
1. Start with $y = f(x)$
2. Solve to make $x$ the subject
3. Replace y and x so y is the subject again.


The domain of $f^{−1} (x)$ is the same as the range of $f(x)$. Th e range of $f^{−1} (x)$ is the same as the domain of $f(x)$.

```ad-note
title:NOTE
color:68,87,80
Only one-to-one functions can have inverses. Some functions may be self-inverse, meaning that they are their own inverse function. 

```

A function and it's inverse when plotted are reflections of one-another in the line of y=x. 

![[Pasted image 20211219192003.png|250]]

## Rational Functions

A rational function is a ratio between two polynomials: $f(x) = \frac{p(x)}{q(x)}$.

If the function is of form:$$f(x) = \frac{ax+b}{cx+d}$$


- Vertical asymptote $x = -\frac dc$ (where cx+d = 0)
- Horizontal asymptote $y=\frac ac$
- X-Intercept at $x = -\frac ba$ (where ax+b =0)
- Y-Intercept at $y = \frac bd$ (where x = 0)

![[Pasted image 20211219194346.png|250]]