# Ordinary Differential Equations
#maths 
## What are they?
A differential equation is simply an equation which relates one or more functions and their [[Differentiation|derivatives]]. 

A good example of this would be:
$$F= ma$$
$$F =m \frac{dv}{dt}$$
$$F = m \frac{d^2s}{dt}$$

There is a differential relationship between acceleration, velocity, and displacement.

A differential equation states how a rate of change in **one variable is related** to other variables.

## Separating Variables
When solving a differential equation it may be useful to separate variables in order to find an appropriate expression.  

If $\frac{dy}{dx} = f(x)g(y)$:
$$\int \frac 1{g(y)}dy = \int f(x) dx$$

This can be used to find an expression for x or y, which could answer a question or lead to a solution. 

## Modelling
Generally, a model will take the form of:
$$\frac {dn}{dt} = kn(a-n)$$
Where:
- n = population after time
- k = relative growth
- t = time
- a = Constant (Changes based on question)

Questions will give you some of these parameters and ask for others, or ask you to state the differential equation which models the problem. 

The most important thing here is to remember the general form. 

## Integrating Factor
The [[Integration|integrating]] factor method is used to find an exact solution to ordinary differential equations.

The steps are as follows:

- Put the equation into the Standard Form:
$$\frac{dy}{dx} + p(x)y = q(x)$$
- Find the Integrating Factor I:
$$I = e^{\int p(x) dx}$$
- Multiply our STD form equation by I and simplify:
$$I \frac{dy}{dx} + Ip(x)y = Iq(x)$$
When simplifying, it may be useful to attempt to use a 'reverse' product rule. 
The goal of the simplifying step is to factorise the derivative out of the equation.
$$\frac {dy}{dx}(Iy) = Iq(x)$$
- Integrate both sides:
$$\int \frac {dy}{dx}(Iy) dx = \int Iq(x) dx$$
$$Iy + C = \int Iq(x) dx$$

Here we can finally solve for y. 
## L'Hopital's Rule
L'Hopital's Rule states that:

$$\lim_{x \to c} \frac{f(x)}{g(x)} = \lim_{x \to c} \frac{f^{'}(x)}{g^{'}(x)} $$

It is used whenever direct substitution of a given limit is indeterminate ($\frac 00$ or $\frac{\infty}{\infty}$) to find the determinate limit.

If the rule doesn't give you a determinate limit after applying it once, you can reapply it until a suitable result is found. 
## Euler's Numerical Method 
Sometimes, we are given equations which we cannot solve. In this case, we can use a recurrence relation approximate the appearance of the function. 
$$x_{n+1} = x_n + h$$
$$y_{n+1} = y_n + h(\frac{dy_n}{dx})$$
Where h is the step (how much we increase x for every n).

The smaller the step is, the more accurate the final graph will be. By this same merit, the graph will also take longer to plot as more points will have to be calculated. 

## Maclaurin Series 
The Maclaurin Series of a function is an infinite sum of terms that are expressed in terms of the function's derivatives at a single point. 

When the series converges, the sum of terms should equal the function.
$$f(x) = a_0 + a_1x + a_2x^2 + a_3x^3+...$$
The derivative of the function should equal the derivative of the series. 
$$f^{'}(x) = a_1 + 2a_2x + 3a_3x^2 + ...$$
This continues infinitely.

Here, $a_n = f^n(0)$. 
This isn't exponents, this is derivatives: $f^{'}(0),f^{''}(0)$ etc.

It is an approximation of a particular function, and questions will typically give you a specific order to go up to. The higher the order, the closer to the original function it is. 


A generalisation of the series:
$$\sum \frac{f^n(0)} {n!} = a_n$$

The steps for solving a Maclaurin Series question are:

- Find the derivatives (as many as the order requires)
- Evaluate each derivative @ x = 0
- Substitute into the Maclaurin Series Formula.

There are a few 'special formulas' for which the Maclaurin Series is already given:
![[Pasted image 20211218161910.png|180]]

You can find them yourself, but the series are already given so it's unnecessary unless the question asks for it.

## Substitution

Substitution is a known method of solving differential equations. Normally, the substitution is given.

The main steps are:

- Make $\frac {dy}{dx}$ the subject. 

- Substitute with the given substitution.
- Simplify (make the substitution the subject).
- Substitute the original variable back in to the formula. 
- Solve for y.