# Polynomials
#maths 

## What are Polynomials?
A polynomial is an expression which consists of constants, variables and coefficients.

```ad-note
title:NOTE
color:67,86,80
Two polynomials being equal means that they have the same order and all of their coefficients are equal.
```


##  Factor Theorem

```ad-note
title:Theorem
icon:calculator
color:67,86,80
If the value of a polynomial expression is zero when $x = \frac ba$, then $(ax-b)$ is a factor of the expression.

```

Substitute $\frac ba$ in for x to prove it's a factor.

## Remainder Theorem

```ad-note
title:Theorem
icon:calculator
color:67,86,80
The remainder when a polynomial expression is divided by $(ax-b)$ is the value of the expression when $x = \frac ba$.

```

Substitute $\frac ba$ in for x to find the remainder.
