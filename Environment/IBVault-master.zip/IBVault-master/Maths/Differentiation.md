# Differentiation
#maths 

Differentiation is defined simply as the process of finding the rate of change of an equation. It's reverse operation is [[Integration]]. 

## Basics
When the first derivative of a curve is 0, the graph is at a stationary point.

When the 2nd derivative of the curve is 0, the graph is at a point of inflexion. This means that the graph is changes concavity at that point. 

The 2nd derivative is found by differentiating the first derivative. 

## Tangents and Normals
The tangent to a curve at a given point is a straight line which touches the curve and has the same gradient at that point.
Finding the tangent requires knowing the gradient at that point. 

Normals are lines which pass through the graph and are perpendicular to the tangent.

![[Pasted image 20211219211709.png|300]]

For the point on a curve $y = f(x)$ with $x=a$:

- The gradient (m) of the tangent is $f^{'}(a)$

- The gradient (m) of the normal is $-\frac 1{f^{'}(a)}$

- The coordinates of the point are $x_1 = a$, $y_1 =f(a)$

- Use $y-y_1 = m(x-x_1)$ to find the equation of the tangent or normal.
## Product Rule

The product rule is used whenever you need to differentiate the product of two functions

It states that:

```ad-note
title:Equation
icon: calculator
color: 66,87,80

$$\frac{d(uv)}{dx} = u\frac{dv}{dx} + v\frac{du}{dx}$$
```

## Chain Rule
The Chain Rule is used whenever you need to find the derivative of a composite function.

It states that:

```ad-note
title:Equation
icon: calculator
color: 66,87,80


$$\frac{dy}{dx} = \frac{dy}{du} \frac{du}{dx} $$
```

For example:

$$ y = (x^2 +1)^2 $$
$$ u = x^2 + 1 $$
$$ y = u^2 $$
$$\frac{dy}{dx} = 2u \times 2x$$
$$ = 2x(2x^2 + 2)$$
$$= 4x(x^2+1)$$

We notice that for a simple Chain Rule problem, we can skip a few steps.

Bring the power of the outside down : $2(x^2+1)$
Then find the derivative of the inside and multiply it by the outside: $4x(x^2+1)$


## Quotient Rule

The Quotient Rule is used whenever you need to find the derivative of the division of two functions.

It states:

```ad-note
title:Equation
icon: calculator
color: 66,87,80

$$\frac{dy}{dx} = \frac{v\frac{du}{dx} -u\frac{dv}{dx}}{v^2} $$

```

## Implicit Differentiation
Implicit Differentiation allows us to find the derivatives of equations where both x and y (or equivalents) do not directly lead to each other.

**Explicit**: y = some function of x

**Implicit**: some function of y and x = a certain number.

In Implicit Differentiation, we would derive as we normally would.

Whenever we find the derivative of y, we would multiply it by $\frac{dy}{dx}$.

For example:

$$ y^2 + x^2 = 1$$
$$ 2y\frac{dy}{dx} + 2x = 0$$
$$ \frac{dy}{dx} = -\frac{x}{y} $$


## First Principles
The derivative is known as the instantaneous rate of change of a curve. 

Derivatives by first principles involves the use of algebra in order to find the general expression of the slope of a curve.


$$f^{'}(x) = \lim_{h \to 0} \frac{f(x+h) -f(x)}{h}$$

Example:

To find the derivative of $x^2$, we would do:

$$f(x) = x^2$$
$$f^{'}(x) = \lim_{h \to 0} \frac{(x+h)^2 - x^2}{h}$$
$$= \frac{x^2 + 2hx + h^2 - x^2}{h}$$
$$ = \frac{2hx}{h} + \frac{h^2}{h}$$
$$= 2x$$

Once we are no longer dividing by zero, we can safely plug 0 in for h. 

## Kinematics

![[Pasted image 20211219211532.png|350]]