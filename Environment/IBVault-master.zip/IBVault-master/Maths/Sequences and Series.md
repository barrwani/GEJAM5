# Sequences and Series
#maths 

## Sequence VS Series
A sequence is a list of numbers in a specified order.

A series is the sum of a sequence.

$u_n$  is the value of the nth term of a sequence.
The general notation for a series is:
$$\sum_{r=1}^{r=n} f(r) = f(1) + f(2) + ... + f(n)$$
The bottom value is where we start, and the top value is the end. 

## Arithmetic
Arithmetic Sequences have a common difference $d$ which is added (or subtracted) every term. 
### Sequence

The general equation for an arithmetic sequence is:
$$u_n = u_1 + (n − 1)d$$

Where $u_n$ is the nth term, $u_1$ is the first term, $n$ is the number of terms and $d$ is the common difference.

### Series
To find the sum of an arithmetic sequence, there are two formulas available. 

For when you know the first and last terms:
$$S_n = \frac n2 (u_1 + u_n)$$

For when you know the first term and the common difference:
$$S_n = \frac n2 (2u_1 + (n-1)d)$$

## Geometric
Geometric sequences have a constant ratio, called the common ratio, $r$, which is multiplied every term.
### Sequence
The general equation for a geometric sequence is:
$$u_{n} = r^{n-1} \times u_1$$

Where $u_n$ is the nth term, $u_1$ is the first term, $n$ is the number of terms and $r$ is the common ratio.

### Series
To find the sum of a geometric sequence, there are two formulas available:

When common ratio is less than one:
$$S_n = \frac{u_1(1-r^n)}{1-r}$$

When common ratio is greater than one:
$$S_n = \frac{u_1(r^n-1)}{r-1}$$

#### Infinite Geometric Series
If a geometric series grows or decreases without limit, it is referred to as **divergent**.  

If the sum gets closer and closer to a finite number, The series is **convergent**. This occurs when the terms get infinitesimally small in magnitude. 

To find the sum of an infinite geometric sequence, we use this equation:

$$S_n = \frac{u_1}{1-r}$$
Where $|r|<1$.  If it isn't, the series will not converge.