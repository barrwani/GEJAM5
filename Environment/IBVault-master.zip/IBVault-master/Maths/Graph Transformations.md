# Graph Transformations
#maths 

## Translation
Translation is simply moving the graph in any direction without affecting it's shape in any way.

![[Pasted image 20211219180047.png|300]]
The graph of $y= f(x+d)$ would be moved left by $d$. If $d$ is negative the graph moves right.
The graph of $y= f(x) + c$ would be moved up by $c$. If $c$ is negative the graph moves down.

## Squash & Stretch
Squash and Stretch involve changing the shape of the graph by some scale factor.

A vertical stretch will not affect the horizontal axis and a horizontal stretch will not affect the vertical axis. 

Both can occur at the same time. 



### Vertical
In the graph of $y =pf(x)$,  the graph of $y = f(x)$ is stretched vertically away from the x axis according to the scale factor $p$. 

If $p$ is less than 1 and greater than zero, the graph is squashed. 

If $p$ is greater than 1, it is stretched. 

If $p$ is negative, the graph will be stretched/squashed by the S.F of $p$ and then reflected in the x-axis. 

![[Pasted image 20211219180532.png|300]] 

### Horizontal
In the graph of $y =f(qx)$,  the graph of $y = f(x)$ is stretched horizontally towards the y axis according to the scale factor $\frac 1q$. 

If $q$ is less than 1 and greater than 0, it is considered a stretch away from the y-axis.

If $q$ is negative, the graph will be stretched/squashed by the S.F of $\frac 1q$ and then reflected in the y-axis. 
![[Pasted image 20211219180546.png|300]]

## Reflection
Reflection is simply flipping the graph in an axis. 
The graph $y = f(x)$ is reflected in the x-axis if $y = -f(x)$
![[Pasted image 20211219181507.png|250]]
The graph $y = f(x)$ is reflected in the y-axis if $y = f(-x)$
![[Pasted image 20211219181456.png|200]]

## Modulus
A modulus graph would be the same as a normal graph, but one or more axis is restricted to being purely positive. 

The graph of $y = f(x)$ becomes a modulus graph if $y = |f(x)|$
![[Pasted image 20211219181654.png|270]]
## Consecutive
There is an order of operations for consecutive transformations:
1. Horizontal Shift
2. Horizontal Stretch/Squash
3. Reflection over y-axis
4. Vertical Stretch/Squash
5. Reflection over x-axis
6. Vertical Shift

## Reciprocal 
A reciprocal function turns the graph of $y = f(x)$ into $y = \frac 1{f(x)}$

## Symmetry 
Graphs can be symmetrical in many ways.
### Two-Fold Symmetry
Rotating the graph by 180 degrees about a given point will produce the same graph
![[Pasted image 20211219185235.png|250]]


### Reflection Symmetry
Reflecting the graph in a given line will produce the same graph
![[Pasted image 20211219185308.png|250]]

### Translational Symmetry 
Shifting the graph will produce the same graph.
![[Pasted image 20211219185334.png|250]]

## Odd and Even Functions
If the graph has two-fold symmetry about the origin, it is an **odd** function. 
$f(-x) = -f(x)$

If the graph has reflectional symmetry in the y-axis, it is an **even** function. 
$f(x) = f(-x)$

### Rules
Adding:
-   The sum of two even functions is even
-   The sum of two odd functions is odd
-   The sum of an even and odd function is neither even nor odd (unless one function is zero).

Multiplying:
-   The product of two even functions is an even function.
-   The product of two odd functions is an even function.
-   The product of an even function and an odd function is an odd function.