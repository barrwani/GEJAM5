# Complex Numbers
#maths 
## Basics
The square root of a negative number is an imaginary number. The quantity:
$$ i = \sqrt{-1} $$


A complex number consists of:
- the 'real' part
- the  'imaginary' part

$$z = x + iy $$ where x and y are real numbers. 

**The 'real' part of this number is the x, and the 'imaginary' part is the iy.
**   

If the imaginary part of a complex number is equal to zero, then the complex number is purely real.

It is purely imaginary if the real part is equal to zero.

```ad-note
color: 66,87,80
Treat i as a variable for the most part:
$$ i^2 = -1 $$
$$ i^3 = -i $$
$$ i^4 = 1 $$
When we bring i to a power we can change its value.
```
## Other Forms
There are several other ways of representing complex numbers. 
### Polar Form
Below is the process of converting the Cartesian (rectangular) form to the Polar form.

![|450](https://www.onlinemathlearning.com/image-files/convert-complex-number-polar.png)

 
The polar form can be represented on a graph, where the Y axis is the imaginary part and the X axis is the real part.

The equation for the polar form is:

 $$ z  = r(\cos(\theta) + i\sin(\theta)) $$
 $$ z = rcis(\theta) $$

### Euler's Form
Below is a conversion from Polar Form to Euler's Form:

$$ re^{i\theta} = r[\cos(\theta) + i\sin(\theta)] $$

## De Moivre's Theorem
$$ [r(\cos(\theta) + i\sin(\theta))]^n = r^n[\cos(n\theta) + i\sin(n\theta)] $$

$$ (rcis(\theta))^n = r^n(cis(n\theta)) $$

```ad-note 
title:NOTE
color: 66,87,80
Use De Moivre's to find exponents of a complex number. 
```

## Complex Conjugates
 
- A complex conjugate is a complex number which has an equal real part in magnitude and sign and an equal imaginary part in magnitude, but opposite in sign.

$$ z = x+iy $$
$$z^* = x-iy $$

- The sum of a number and it's conjugate results in a purely real number
- The difference between (subtraction) a number and its conjugate is a purely imaginary number 

```ad-note
title:NOTE
color: 66,87,80
The number of complex roots in any polynomial is always even, as if a complex number is present as a root, it's conjugate will be too.
```

$$\sum_{n=1}^{100} ln(2n \times3^n) = \sum_{n=1}^{100}ln(2) + ln(n) + nln(3)$$