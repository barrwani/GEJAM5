# Standing Waves
#physics #maths

A standing wave is a wave in which the frequency and amplitude are constant, meeting in superposition (opposite directions)

The Key Equation is:
$$v = f \lambda$$
The peaks and crests of a standing waves are known as the anti-nodes. The central points are known as the nodes.

A Harmonic is a frequency which is a multiple of an existing frequency. In music, the Second Harmonic of A at 440Hz is 880Hz.


## Fixed at Both Ends
The length of the string is proportional to its wavelength and depends on the harmonics.

![[Pasted image 20220120181424.png|350]]


- The first harmonic will have a wavelength equal to half the length of the string. 

- The second harmonic will have a wavelength equal to the length of the string.

- The third harmonic will have a wavelength equal to 1 and a half times the length of the string.

Et cetera. 

## Open at one End, Closed at the other

The length of the object  is proportional to its wavelength and depends on the harmonics.

![[Pasted image 20220120182710.png|250]]

- The first harmonic will have a wavelength equal to a quarter of the length of the object. 

- The second harmonic will have a wavelength equal to 3 quarters of the length of the object.

- The third harmonic will have a wavelength equal to 5 quarters of the length of the object.

Et cetera. 

## Open at Both Ends


![[Pasted image 20220120182730.png|250]]

- The first harmonic will have a wavelength equal to half of the length of the object. 

- The second harmonic will have a wavelength equal to the length of the object.

- The third harmonic will have a wavelength equal to 1 and a half times the length of the object.

Et cetera. 