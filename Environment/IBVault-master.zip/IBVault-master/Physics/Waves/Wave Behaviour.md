# Wave Behaviour
#physics #maths 


## Reflection

Reflection is the change in direction of a wavefront at an interface between two different media so that the wavefront returns into the medium from which it originated.

![|300](http://cnx.org/resources/55c2011fd4cdc676168cc52e7aadaff7/Figure%2026_02_01.jpg)

## Refraction
Refraction is known as the change of the speed of an electromagnetic wave when entering another medium. 

The frequency of the refracted wave remains the same.

The Critical Angle is when the refracted angle is 90 degrees. Anything higher than this will result in a total internal reflection of the wave in the same medium it came from.

![|450](https://mammothmemory.net/images/user/base/Physics/Refraction/Different%20refractive%20index/different-refractive-indices-r13-3.68f3244.jpg)

The important equation to know is Snell's Law:

$$\frac {n_1} {n_2}= \frac {\sin(i)}{\sin(r)} = \frac{v_2}{v_1}$$

Where:
$n_1$ and $n_2$ are the refractive indexes of the two mediums
i is the angle of incidence and r is the angle of refraction
$v_2$ and $v_1$ are the wave speeds of the wave in the two mediums. 


## Slit Diffraction

When an electromagnetic wave is emitted through 2 slits, it is diffracted.

Diffraction is defined as the bending of waves around the corners of an obstacle or through an aperture into the region of geometrical shadow of the obstacle/aperture.

![[Pasted image 20220120204739.png|350]]

The Equation for fringe separation (the distance between points of constructive interference) is:
$$S = \frac{\lambda D}d$$
Where S is the Fringe Separation, $\lambda$ is the wavelength, D is the distance between the screen and the slits, and d is the distance between the two slits.

The path difference is defined as the difference in distance travelled by two waves to reach the same point. 

If the path difference is equal to $n\lambda$ (a whole wavelength or a multiple of a whole wavelength), there is constructive interference.

If the path difference is equal to $(n+1/2)\lambda$  (half a wavelength or a multiple of half a wavelength), there is destructive interference. 

![[Pasted image 20220120205835.png]]

