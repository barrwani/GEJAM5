# Wave Characteristics
#physics #maths 

## Amplitude, Power, and Intensity

A wave carries energy, and the rate at which energy is carried is known as the Power of the wave. 

For example, a 60 W bulb radiates energy in all directions such that 60J of energy are emitted every second.
When some of this power is incident on an area we define the intensity to be: 

```ad-note
title: Equation
color: 66,87,80
$$I = \frac Pa$$
Unit: W/$m^2$
```

If the source of power radiates equally in all directions, the intensity at a distance x from the source is given by:

$$I = \frac P {4\pi x^2}$$

### Constructive and Destructive Interference
Interference occurs when two waves collide.

- Constructive Interference occurs when the two waves are both peaks or both troughs. 
In this case, the amplitude will be the sum of the 2 waves amplitudes.

- Destructive Interference when the two waves are opposite (peak and trough). 
In this case, the amplitude will be the subtraction of the 2 waves amplitudes. 

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/superposition.jpg?resize=539%2C207&ssl=1)


## Polarisation and Malu's Law

The Polarisation of an electromagnetic wave is known as the plane of its oscillation 

![|500](https://cdn1.byjus.com/wp-content/uploads/2019/02/polarisation-by-scattering.png)

Light from the sun is unpolarised.


Malus' Law states:
```ad-note
title: Equation
color: 67,86,80
$$I = I_0 \cos^2{\theta}$$

Where:
I is the intensity of the transitted light
$I_0$ is the intensity of the incident (unpolarised) light
$\theta$ is the angle between the two polarisers
```

![|550](https://labster-image-manager.s3.amazonaws.com/201eb4d0-d8fb-4434-b8a1-cd5fb78e1e0c/LGH_MalusLaw.en.x1024.png)

Malus Law can be used to find the intensity of light which has been polarised multiple times, or to find the angle between two polarisers.

```ad-note
title: NOTE
color: 67,86,80
If $\theta$ is 90, then I is 0.
```


Unpolarised light coming into the first polariser will exit the first one with half the intensity. 

If the light was polarised parallel to the first polariser, then it would come through with just the initial intensity