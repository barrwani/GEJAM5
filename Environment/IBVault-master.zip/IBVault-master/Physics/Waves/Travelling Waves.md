# Travelling Waves
#physics #maths 


```ad-note
title: Equations
color: 66,87,80

$$\ c = f\lambda$$
$$f = \frac1t$$
```

## Transverse Waves
Wave direction is perpendicular to the direction of the [[Oscillations]].

- Crests are high points.
- Troughs are low points.


### Constructive and Destructive Interference
Interference occurs when two waves collide.

- Constructive Interference occurs when the two waves are both peaks or both troughs. 
In this case, the amplitude will be the sum of the 2 waves amplitudes.

- Destructive Interference when the two waves are opposite (peak and trough). 
In this case, the amplitude will be the subtraction of the 2 waves amplitudes. 

## Longitudinal Waves

- Wave direction is parallel to the direction of the [[Oscillations]].

- Compressions are when particles are squashed together
- Rarefactions are separations in the medium.




