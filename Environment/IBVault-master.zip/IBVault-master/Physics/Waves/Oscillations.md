# Oscillations
#physics 

## Simple Harmonic Motion (SHM)

Simple harmonic motion occurs when the acceleration is directly proportional to negative displacement.

Acceleration will act in the opposite direction to displacement.

```ad-note
title:Equation
icon: calculator
color:66,87,80
$$ a = -kx$$
```

You will need to remember the shape of the graph of SHM. 

![|350](https://i.stack.imgur.com/ITxAo.jpg)

If an object is in SHM:
- At max displacement:
	- Velocity and Kinetic Energy are 0

	- Potential Energy is Maximum
	- Displacement is Maximum

- At Equilibrium:
	- Velocity and Kinetic Energy are maximum

	- Potential Energy is 0
	- Displacement is 0

```ad-note
title:NOTE
color:66,87,80
Total Energy $E_{total}$ always remains the same. 
```

![|400](https://s3-us-west-2.amazonaws.com/courses-images/wp-content/uploads/sites/2952/2018/01/31200818/CNX_UPhysics_15_02_SHMEnrgPos.jpg)
Here the red line is Kinetic Energy and Blue line is Potential Energy.

## Phase Difference

Multiple waves may be separated by a phase difference between them.

Think of phase difference as a relative shift from one graph to another.

The amount of shift between 2 graphs is known as the phase difference between 2 curves.

```ad-note
title:Phase Difference Equation
icon: calculator
color:66,87,80
$$\phi = \frac{SHIFT}{t} \times 360 \degree $$
```

![|350](https://i.stack.imgur.com/p03UZ.png)

2 Waves are considered in anti-phase when their phase difference is equal to 180$\degree$. The waves would cancel each other out in anti-phase if their amplitudes are equal. 

Otherwise, the larger amplitude will be subtracted from the smaller one to result in a smaller wave.
