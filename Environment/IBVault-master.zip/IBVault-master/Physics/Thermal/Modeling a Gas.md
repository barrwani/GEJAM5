# Modelling a Gas
#physics #maths 

## Ideal Gas Law
The Ideal Gas Law is the equation of state of a hypothetical ideal gas. It is a good approximation of the behavior of many gases under many conditions.

The equation is:

$$PV = nRT$$

Where: 
P = pressure
V = volume
n = moles of gas
R = ideal gas law constant (8.31)
T = temperature


### Ideal Gas
In the situation of an ideal gas, we assume the following:

-   The collisions between molecules are perfectly elastic.
-   The molecules are identical spheres.
-   The volume of molecules is negligible compared to the volume of the gas.
-   Molecules do not interact with each other except when they are in constant.

Which implies:
Absolute temperature is directly proportional to the average KE and average speed of the molecules of an ideal gas.


The ideal gas is based on a list of assumptions stated previously. However, in real gases, such assumptions may not be true.

-   Forces exist between gas molecules in real gases (intermolecular forces).
-   The volume of molecules is not negligible compared to the volume of gas in real gases.

Real gases may behave similarly to ideal gases under high temperatures and low pressure.
