# Heat Capacity & Latent Heat
#physics #maths 

## Internal Energy

Internal energy is the sum of total kinetic energy (total thermal energy) and total potential energy.

Kinetic energy is energy associated with the random/translational rotational motions of molecules.

Potential energy is associated with forces between molecules.

## Specific Heat capacity

The Specific Heat Capacity of a substance is given by:
$$Q = mc\theta$$
Where:
m = mass
c = specific heat capacity
Q = heat energy
$\theta$ = temperature change. 

It is defined by the amount of heat needed to raise the temperature of 1kg of the substance by 1K.

Different substances have different specific heat capacities because of different densities and physical properties.


## Specific Latent Heat


The specific latent heat of a substance is given by:
$$Q = mL$$
Where:
Q = Heat Change
M = mass
L = Specific Latent Heat

**Specific latent heat of fusion:** The amount of heat required to change 1kg of a substance from solid to liquid without any change in temperature.

**Specific latent heat of vaporization:** The amount of heat required to change 1kg of a substance from liquid to gas without any change in temperature.

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/heatcool.gif?resize=300%2C206&ssl=1)

