# Sankey Diagrams and Energy Density
#physics #maths 

## Sankey Diagrams

Sankey diagrams are a way of representing the energy in and out of a system.

The diagram portrays total energy going in from the left, wasted energy pointing downwards, and useful energy leaving to the right. 

The width of the arrows represent the energy value.

The useful + wasted should equal the total.

These diagrams are used to depict efficiency, and can be used to calculate efficiency with the formula

$$\text{efficiency} = \frac{\text{useful output}}{\text{total input}}$$

![[Pasted image 20220421202654.png|350]]


## Energy Density 

Energy density is the amount of energy released by a substance per mass used.

It is used to compare different energy sources.


$$\text{energy density} = \frac{\text{energy released}}{\text{mass of fuel used}}$$

