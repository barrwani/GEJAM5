# Measurement and Units
#physics #maths 

## Errors

Errors can be caused by equipment, environment, human error, etc. 

![](https://i0.wp.com/www.e-education.psu.edu/natureofgeoinfo/sites/www.e-education.psu.edu.natureofgeoinfo/files/image/quality_sys_random.gif?w=1200&ssl=1)

#### Systematic
- Caused by fixed shifts in measurements away from the true value.

- Cannot be reduced by averaging over repeated measurements.

- Caused by bias.
#### Random

- Caused by fluctuations in measurements centered around the true value (spread).

- Can be reduced by averaging over repeated measurements.

- Not caused by bias.


## Uncertainty
Physical measurements are sometimes expressed in the form x±Δx. 

For example, 10±1 would mean a range from 9 to 11 for the measurement.

### types of Uncertainty
#### Absolute Uncertainty
Absolute Uncertainty for a value x is 
$$Δx$$

#### Fractional Uncertainty 
Fractional Uncertainty for a value x is:
$$\frac{\Delta x}x$$

#### Percentage Uncertainty
Percentage Uncertainty for a value x is :
$$\frac{\Delta x}x \times 100$$ 
### Calculating with Uncertainty

#### adding/Subtracting
Sum of absolute uncertainties.
If y = a±b, then Δy=Δa+Δb

#### Multiplication/ Division
Sum of fractional uncertainties