# Magnetic Effects of Electric Currents
#physics #maths 

## Magnetic Fields
Magnetic fields are caused by the presence of magnets or moving charges.

Similar to how an electric charge experiences a force in an electric field, a magnet or an electric current experiences a force in a magnetic field.

The unit of a magnetic field is Tesla (T).

### Field Patterns
Magnetic fields can be graphically represented using magnetic field lines.

- The direction of the field at a point is equal to the direction of the field line passing through that point.
- The magnitude of the field at a point corresponds to the density of the field lines around that point.


Viewing the magnetic field in 3D, dots represent magnetic fields coming out of the page (like the tip of an arrow) and crosses represent magnetic fields going into the page (like the nock of an arrow).

![[Pasted image 20220408131427.png]]


#### Magnets:
![[Pasted image 20220408130914.png|350]]

#### Wire with Current:
![[Pasted image 20220408131057.png||350]]
#### Solenoid With Current:
![[Pasted image 20220408131048.png]]


## Magnetic Force

### Moving Charge in a Magnetic Field

$$\vec F = qv\vec B\sin\theta$$

### ### Wire in a Magnetic Field

$$\vec F = \vec BIL\sin\theta$$
