# Circuits
#physics 

## Voltage, Current, Resistance

#### Voltage:
- Also known as **Potential Difference**
- The measure of the 'electrical pressure' between two points
- Unit V

#### Current
- The measure of the 'rate of flow' of the electric particles (electrons) 
- Unit A

#### Resistance
- Also known as **Impedance**
- The measure of the 'opposite flow' of the current
- Higher resistance = Lower current
- Unit $\Omega$

## Resistance in Circuits

The total resistance of resistors in parallel is always less than the smallest resistor in the parallel network.

```ad-note
color: 66,87,80
Current in a circuit will always  **take the path of least resistance**.
```

#### In Series:
- The total resistance is the sum of each individual resistor

$$R_{total} = R_1 + R_2 + ... R_n$$


#### In Parallel:
- The reciprocal total resistance $\frac1{R_{total}}$ is the sum of the reciprocal resistances in the network

$$\frac1{R_{TOTAL}}  = \frac1{R_1} +  \frac1{R_2} + ... +  \frac1{R_n} $$


## Kirchoff's First Law

-   The total current arriving at a junction is equal to the total current leaving a junction.

-   The current labelled is conventional current (positive to negative).

-   For electrical parallel circuits, this results in the familiar "current splits up" rule.

```ad-note
color: 66,87,80
Keep in mind that this occurs in any parallel circuit. The current is always split according to this law.
```

![](https://physicsteacher.in/wp-content/uploads/2020/12/Kirchhoffs-first-law-explanation-with-diagram-1024x271.jpg)

## Kirchoff's Second Law

- The sum of the ** voltage drops ** in a closed loop must be equal to zero

	- A voltage drop is the amount of voltage lost due to resistance

	- If we measure the potential difference after each resistor and sum them, they should be equal to our initial voltage.

![](https://revisezone.com/Imagedata/Physics/Kirchoffvoltage.jpg)