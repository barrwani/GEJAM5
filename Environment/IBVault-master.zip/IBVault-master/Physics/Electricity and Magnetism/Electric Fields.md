# Electric Fields
#physics #maths 

## Electric Charge, Force, Field

### Charge

Electric charge can either be positive or negative.

Charges with the same sign repel each other and changes with the opposite sign attract.

An object with equal amounts of positive change and negative charge is said to be electrically neutral.

The unit of electric charge is coulomb (C).

The charge of one electron is equal to $$1.6\times10^{-19}C$$

Electric charge is always conserved. While charges could migrate from one body to another, the total charge remains the same.

### Field
Electric fields can be graphically represented as electric field lines.

-   The direction of the field at a point is equal to the direction of the field line passing through that point (arrows from the positive pole to the negative pole).

-   The magnitude of the field at a point corresponds to the density of the field lines around that point. For a uniform electric field, the field lines are straight, parallel and equally spaced.


Non Uniform Fields:

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/u8l4c16.gif?resize=431%2C294&ssl=1)

Uniform Field:
![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/elfield-600x205.jpg?resize=300%2C103&ssl=1)


## Coulomb's Law
Coulomb's Law states:
$$F = k\frac{|q_1| |q_2|}{r^2}$$
where F is the force, k is the Coulomb Constant, q1 and q2 are the charge of the two objects (usually the same when considering two electrons), and r is the radius/distance between the two charges.

The Coulomb Constant k is given as:

$$k = \frac 1 {4 \pi \epsilon_0} = 8.988 \times 10^9 Nm^2 \cdot C^{-2}$$


## Electrical Current

The existence of an electric potential difference across an object causes charges to flow through the object.

Electric current (I) refers to the rate of flow of electric charge and can be given by the equation

$$I = \frac Q t$$
Where I is current, Q is total charge and t is time.

The direction of an (conventional) electric current is opposite to the direction of electron flow.

![[Pasted image 20220406120724.png]]

### AC VS DC

Direct Current (DC) is a uniform current flowing in one fixed direction in a circuit.

DC is usually supplied by acid-based batteries or dry cells.

Alternating Current (AC) is an electric current which periodically reverses direction and changes its magnitude continuously with time. 

AC is usually supplied by the mains (power grid). 

### Potential Difference

The electric potential difference (pd) between two points is equal to the work done (energy) required per unit charge to move from one point to another. It is also known as voltage (V).

$$V = \frac W Q$$
OR
$$V = \frac E Q$$

Where V is voltage, W is work done, Q is charge, and E is energy.

Voltage is analogical to the differences of up streams and down streams where water flow in the stream is the flow of electrons within the circuit.