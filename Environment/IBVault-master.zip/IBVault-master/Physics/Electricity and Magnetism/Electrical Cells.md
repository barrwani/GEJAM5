# Electrical Cells
#physics #maths 


## cells 
A cell in a circuit acts as a source of electrical energy and creates an electric potential difference at its terminals.
A battery is made up of two cells connected.

## Internal Resistance

The internal resistance is the resistance of a source determined by the material it is made up of.

The internal resistance can be used to calculated the EMF.

## Secondary Cells

A secondary cell or battery can be recharged after use by passing current through the circuit in opposite direction to the current during the discharge.
![[Pasted image 20220406153908.png|350]]

## Terminal Potential Difference
The potential difference at the terminals of a source is less than the emf of the source due to internal resistance.

## Electromotive Force (EMF)

The electromotive force (emf) of a source is defined as the energy per unit charge supplied by the source.

The unit for emf is volt (V).

$$E = V + Ir$$
$$E = I(R+r)$$

Where E is the emf, V is the voltage, I is the current, R is the load resistance, and r is the internal resistance.