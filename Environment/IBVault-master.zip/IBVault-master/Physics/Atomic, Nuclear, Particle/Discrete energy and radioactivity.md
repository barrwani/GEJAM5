# Discrete energy and radioactivity
#physics #maths 

## Discrete energy and discrete energy levels
	![[Pasted image 20220409134015.png|400]]
