# Motion

##  SUVAT
The following equations can be used when acceleration in an object is constant:

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/linearformula.png?resize=300%2C248&ssl=1)

## Projectile Motion
An object is said to undergo projectile motion when it follows a curved path due to the influence of gravity.

![|400](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/1.png?resize=539%2C529&ssl=1)

If we assume air resistance to be negligible in a projectile motion:

-   The horizontal component of velocity is constant
-   The vertical component of velocity accelerates downwards at 9.81m/s^2
-   The projectile reaches its maximum height when its vertical velocity is zero
-   The trajectory is symmetric


![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/vector-components.png?resize=280%2C187&ssl=1)

The presence of air resistance changes the trajectory of the projectile by the following

-   The maximum height of the projectile is lower
-   The range of the projectile is shorter
-   The trajectory is not symmetric

## Fluid resistance and terminal speed
    
Air resistance limits the maximum velocity an object could attain from free-falling. For example:

-   If you jump out of a plane and undergo free-falling, you will feel an upward force exerted on you by the surrounding air due to air resistance.

-   As you fall faster and faster due to gravity, this upward force exerted by air becomes greater and greater until it balances your weight. At this point, the net force acting on you becomes zero, and you no longer accelerate.

-   This specific velocity at which you stop accelerating during a free-fall is called the terminal velocity

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/fimage006.gif?resize=472%2C182&ssl=1)