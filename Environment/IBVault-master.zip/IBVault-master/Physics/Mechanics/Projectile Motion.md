# Projectile Motion
#physics #maths 

Projectile Motion is the **motion of objects thrown into the air** with an *initial velocity* (**u**). The only [[Forces]] being applied past the initial force are applied by gravity. 

```ad-note
title: NOTE
color: 68,87,80
In a typical projectile motion question, you will be given some values from the [[SUVAT]] equations and asked to find a different component.
``````
Velocity is a vector ([[Vectors]]), meaning that it has an x component and a y component.

The components of the initial velocity **u** are:

$$u_x = u\cos(\theta)$$
$$u_y = u\sin(\theta)$$
![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/vector-components.png?resize=280%2C187&ssl=1)
```ad-note
color: 66,87,80

For IB-level questions we would typically neglect air resistance, and only consider objects close to the Earth's surface, meaning that acceleration is always **g**.

Because of these assumptions, we can always assume the path to be parabolic
```
![|400](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/1.png?resize=539%2C529&ssl=1)

Above, the red line depicts the path of a projectile with air resistance, and the blue line depicts a projectile with negligible air resistance. 

- Projectile Motion is the combined motion of two independent motions simultaneously.

	- Our x direction will typically have a constant velocity due to negligible air resistance

	- Our y direction will typically have a constant acceleration due to gravity



