# Work, Energy, Power
#physics #maths 

## Energy

### Kinetic Energy
Kinetic energy (KE) is the energy of a body due to its motion and is given by the equation:

$$E_K = \frac 12 mv^2 $$
 
Where $E_K$ is the Kinetic Energy, $m$ is the mass and $v$ is the velocity.


### Gravitational Potential Energy
The gravitational potential energy (GPE) of an object changes with its height and is given by the equation:

$$E_P = mgh$$

Where $E_P$ is GPE, $m$ is mass, $g$ is the gravitational field strength and $h$ is the relative vertical height.

### Elastic Potential Energy
Elastic energy is potential energy stored as a result of the deformation of an elastic object such as the stretching of a spring and is given by the equation:

$$E_P = \frac 12 kx^2$$

Where $E_P$ is EPE, $k$ is the spring constant and $x$ is the extension of the spring. 
## Work Done

Work done measures the transfer of energy due to a force and is a scalar quantity.

The work done W by a force F on an object is given by the equation:
$$W = F \times s \times \cos \theta$$
Where $W$ is the Work Done, $F$ is the force, $s$ is the displacement and $\theta$ is the angle between the force and direction of motion.

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/workandenergy_clip_image002.jpg?resize=430%2C100&ssl=1)

In a force-displacement graph, work done is the area under the curve.


## Power
Power (P) is the work done or the energy output per time given by the equation:
$$P = \frac Wt$$
Where $P$ is Power, $W$ is Work Done and $t$ is time.

For constant force acting on an object with constant velocity, the power is given by the equation: 

$$P=Fv$$

## Conservation of Energy

Energy can neither be created nor destroyed; it can only be changed from one form to another. For example:

-   An electrical heater transforms electrical energy to thermal energy.
-   A falling object transforms potential energy to kinetic energy.

Total energy of an isolated body remains constant. In other words: $ΔKE+ΔPE=0$

### Efficiency

Efficiency is the ratio of useful energy output to energy input as a percentage given by the equation:

$$\text {Efficiency} = \frac {\text{Useful Energy Output}}{\text{Energy Input}} \times 100$$
$$\text {Efficiency} = \frac {\text{Useful Power Output}}{\text{Power Input}} \times 100$$

