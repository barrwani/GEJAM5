# Momentum
#physics #maths 

Momentum can be defined as "mass in motion." 

All objects have mass; so if an object is moving, then it has momentum - it has its mass in motion. 

Momentum is a Vector ([[Vectors]]).

A good example of momentum is [[Projectile Motion]].

The equation for momentum is as follows:
```ad-note
title: Equation
color: 66,87,80
icon: calculator
$$p = mv$$

```
Where $p$ is momentum, $m$ is mass and $v$ is velocity.

**Units: kgm/s, Ns**

## The Law of Conservation of Momentum

The law of conservation of momentum states that:
```ad-quote
color: 66,87,80
title: The Law of Conservation of Momentum
For two or more bodies in an isolated system acting upon each other, their total momentum remains constant unless an external force is applied.
```

In a closed system, the total momentum before and after a collision between objects is equal.

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/momentumformula2.png?resize=300%2C258&ssl=1)

## Impulse
Impulse is the measure of the effect of a force acting over a period of time to change the momentum of an object. 

The equation for impulse is given as:
```ad-note
title: Equation
color: 66,87,80
icon: calculator
$$\Delta p = F\Delta t$$

Change in momentum (Impulse) = Force * time

$$\Delta p = p_f - p_i$$

Change in momentum (Impulse) =Final Momentum - Initial Momentum
```

This equation is derived from the fact that net force ([[Forces]]) is equal to the [[Differentiation]] of momentum with respect to time. 

## Collisions

### Elastic Collisions
An elastic collision is an encounter between two bodies in which:
- The kinetic energy is conserved
- The momentum is conserved

- The objects bounce off of each other

### Inelastic Collisions
An inelastic collision is an encounter between two bodies in which:
- The kinetic energy is **NOT** conserved

	- $E_{kinetic}$ turns into $E_{thermal}$
- The momentum is conserved

In a **Perfectly Inelastic** collision, the objects will **stick**. 