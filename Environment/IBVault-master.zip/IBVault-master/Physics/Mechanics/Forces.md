# Forces
#physics #maths 

## Objects as point particles
    

Forces change the velocity or shape of objects.

The unit of force is newton (N).

Objects are represented as a point mass to enable the representation for forces as arrows in free-body diagrams.

## Free-body diagrams
 
On a free body diagram, forces acting on an object are represented as arrows which stem from a point mass.

The length and direction of the arrows corresponds to the magnitude and the direction of the forces acting on the body of interest.

The Weight Force stems from the Center of Mass. 
The Normal Force stems from the Point of Contact between the object and the surface. 

![[Pasted image 20211221190923.png|250]]
Determining the resultant force:

1. Resolve all acting forces into horizontal and vertical components

2. Add up the horizontal components

3. Add up the vertical components

4. Combine the sum of horizontal components and the sum of vertical components


## Translational Equilibrium
	
A body is said to be in translational equilibrium if it the net force acting on the body is zero. This means the body is either at rest or travels at constant velocity. For example:

-   Mass hanging at rest
-   Elevator moving upwards at constant velocity
-   Parachutist reaching terminal velocity


## Newtons Laws of Motion

```ad-quote
title: First Law
color: 67,86,80
Newton’s First Law (Law of Inertia) states that a body remains at rest or travels with constant speed along a straight line unless acted upon by an external force. (Net force = 0)
```


```ad-quote
title: Second Law
color: 67,86,80
Newton’s Second Law states that net force is directly proportional to acceleration and to mass. (F=ma).
```

```ad-quote
title: Third Law
color: 67,86,80
Newton’s Third Law states that if a body A exerts a force on body B, then body B exerts a force of the same magnitude but in the opposite direction of body A.

This pair of forces is called an action-reaction pair, which must act on two different bodies.
```

## Friction

Friction is a non conservative force which opposes motion. 

If there is no motion, then there will be no force caused by friction.

The surface area and velocity of the object does not affect the friction.

There are also two types of friction for solid surfaces: static friction and kinetic friction. 


Static friction is that which **stops** objects from beginning to move. 

Kinetic friction is that which **slows** objects down when they are moving. 

Static friction is **always** larger than kinetic friction.

![](https://i0.wp.com/ibphysics.org/wp-content/uploads/2016/01/frictiongraph.jpg?resize=344%2C275&ssl=1)


These two types of friction are defined individually by their constants µs and µk respectively.

The forces of friction are also **dependent** on the normal force the surface is applying. 


The force of static friction is equivalent to the Coefficient of Static Friction $\mu_s$ multiplied by the normal force $R$ .

$$F_{static\space friction} = \mu_s \times R$$

The force of dynamic friction is equivalent to the Coefficient of Dynamic Friction $\mu_d$ multiplied by the normal force $R$ .

$$F_{dynamic\space friction} = \mu_d \times R$$


The Normal Force is **always** perpendicular to the surface. 