# SUVAT
#physics #maths 

The SUVAT equations are 5 equations that relate displacement (s), initial velocity (u), final velocity (v), acceleration (a), and time (t). These equations are the quintessential equations for motion.

Some SUVAT Variables have a [[Ordinary Differential Equations| Differential]] Relationship. 


## The equations

!["SUVAT"](https://i.stack.imgur.com/VV7lO.png)

## Displacement
- Displacement is known as the current position of an object relative to its starting position. 

- It is a Vector ([[Vectors]]) and can be found with [[Integration]] of velocity with respect to time
- Distance is the scalar form of displacement, and does not take into account direction

	- Traveling 5km forward and 5km backwards would be 0km displacement and 10km distance

## Initial and Final Velocity
- Velocity is known as the rate of change of displacement

- In a typical question, you will be given one or both of the velocities
- It is a Vector ([[Vectors]]) and can be found with [[Differentiation]] of displacement with respect to time
- It can also be found with [[Integration]] of acceleration with respect to time
- Speed is the scalar form of velocity
## Acceleration
- Acceleration is known as the rate of change of your velocity. 

- It is a Vector ([[Vectors]]) and can be found with [[Differentiation]] of velocity with respect to time.

## Time
- Time is self-explanatory.