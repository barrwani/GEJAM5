# Circular Motion
#physics #maths

## Uniform Circular Motion

Uniform circular motion refers to circular motion at constant speed.

In a uniform circular motion, speed is constant while (angular) velocity and (angular) acceleration are constantly changing.

-   While the magnitude of its velocity remains constant, the direction of its velocity is constantly changing.
-   The acceleration causing this change in velocity is always directed towards the center of the circular path.


The period is the time taken for the object to complete one full circle and is usually calculated in seconds. The frequency can be calculated by 1/period and is usually measured in Hz.

## Centripetal Force

Centripetal force is the corresponding force (resultant force) which causes the centripetal acceleration.


Direction: Pointing towards the center of the circle / perpendicular to the instantaneous velocity

The magnitude of the Centripetal Force is given by:

$$F_C = \frac{mv^2}r$$
$$F_C = m \omega ^2 r$$

Where:
m = mass
v = scalar velocity
$\omega$ = angular velocity
r = radius
## Centripetal Acceleration

The acceleration which gives rise to a circular motion is called the centripetal acceleration. Its magnitude is given by:
$$ a = \omega ^2 r$$
$$a = \frac {v^2}{r}$$

Where: 
a = acceleration
$\omega$ = angular velocity
v = scalar velocity 
r = radius

It is directed towards the center of the circular motion and is perpendicular to the instantaneous velocity of the object.