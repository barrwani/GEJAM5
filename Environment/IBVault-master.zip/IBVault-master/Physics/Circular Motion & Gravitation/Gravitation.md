# Gravitation
#physics #maths 

## Newton's Law of Gravitation

The gravitational force between two objects can be calculated using Newton’s universal law of gravitation:

$$F_g = \frac{G m_1m_2}{r^2}$$

Where:
G = Gravitational Constant ($6.668 \times 10 ^{-8}$)
$m_1$ = mass of first object
$m_2$ = mass of second object
R = distance between objects

## Field Strength

The gravitational field strength at a point is the force per unit mass experienced by a test mass at that point.

The gravitational field strength (g) due to an object is given by:

$$g = \frac Fm$$

Where:
g = Gravitational Field Strength
F = Gravitational Force
m = mass of object

Gravitational field strength at the surface of a planet

-   The gravitational field strength at the surface of a planet can be calculated by using the equation for gravitational field strength and substituting M and r by the mass and the radius of the planet respectively.


-   If we calculate the gravitational field strength at the surface of the Each using the mass and the radius of the Earth, we would obtain the value 9.81m/s^2, which is equal to the acceleration due to gravity on the surface of the Earth.


-   Different planets have different radii and masses. Consequently, different planets have different gravitational field strengths.