# IBVault
**Obsidian Vault for IB notes**

## Installed Plugins:
- Admonition
- Better Word Count
- Calendar
- Kanban
- Mind Map
- Recent Files
- Search on the Internet
- Sliding Panes
