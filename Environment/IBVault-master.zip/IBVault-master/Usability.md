# Usability
#cs 

## What is Usability

Usability is the ease of use and learnability of a human-made object. 

It consists of Accessibility and Ergonomics.

### Accessibility 
Refers to the design of products, devices, services, or environments for people with disabilities or specific needs.

### Ergonomics
Refers to the optimisation of the **form** of a product, device, service, or environment to fit its **function**.