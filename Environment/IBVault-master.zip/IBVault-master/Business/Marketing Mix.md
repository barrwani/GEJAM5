# Marketing Mix
#business 
///


## Product

## Price

## Place

## Promotion


# Extended Marketing Mix


## People

## Processes

## Physical Evidence