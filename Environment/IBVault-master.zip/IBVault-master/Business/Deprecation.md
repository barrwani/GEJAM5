# Deprecation
#business 
## Straight Line Deprecation


## Reducing Balance Deprecation

