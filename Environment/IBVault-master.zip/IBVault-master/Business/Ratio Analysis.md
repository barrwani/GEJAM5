# Ratio Analysis
#business #maths 