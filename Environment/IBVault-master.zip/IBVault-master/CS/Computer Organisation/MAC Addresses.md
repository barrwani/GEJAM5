# MAC Addresses
#cs 

## Basics

- Every device has it's own personal MAC address, written in hexadecimal (concise [[Binary Representation]]). 
- These MAC addresses are used for identification and verification of data senders and recipients.
- They are hard-coded into the hardware so they can't be changed easily.
- When two devices are communicating, they share each other's MAC addresses.

```ad-note
color: 66,87,80

MAC addresses differ from [[IP Addresses]] in that a MAC address tells you 'who' a device is, whereas the IP tells you the device's location.

The IP of a device is constantly changing, but MAC addresses are permanent.
```

## Components

MAC addresses can tell us information about hardware.
They are split into two parts:
- The first three pairs: belong to a manufacturer
- The last three pairs: are unique to the hardware

Every pair is a set of two hexadecimal digits.