# Logic Gates
#cs #maths 

Logic Gates have not become more complicated than they were in GCSE. 

![Symbols](https://www.elprocus.com/wp-content/uploads/Basic-Logic-Gates-with-Truth-Tables.jpg)

#### AND
Both conditions must be true for the outcome to be true

#### OR
Either condition can be true for the outcome to be true

#### NOT
Whatever is input will be inverted

#### XOR
Similar to OR, but both cannot be true for the outcome to be true

#### NOR
Opposite OR

#### NAND
Opposite AND

## Standard Order of Precedence

In a logic gates question, you may be asked to draw the diagram for a given problem. 

Similar to BODMAS in regular arithmetic, a standard order of precedence exists.

1. Bracketed Quantities
2. NOTs
3. ANDs
4. ORs
