# Interface
#cs 

## GUI (Graphical User Interface)

A graphical user interface (GUI) is used to interface software graphically using a pointer and graphic monitor.

##### Advantages:

- Easier for new users to use since they don't need to learn commands Icons are used to identify commands, which is easier for users to identify/remember

- Commands can be grouped and organized in menus and toolbars

##### Disadvantages:

- Harder to implement for the programmer 

- Requires more memory and processing power to run 
- Requires a graphic monitor and pointer (mouse) to use


### GUI Elements

The core of a GUI is **WIMP** (Windows, Icons, Menus, Pointers)

## CLI (Command Line Interface)

A CLI is used to interface software with text using a command line.

##### Advantages:
- Easier to implement for the programmer 

- Requires less memory and processing power to run 
- Can be used without a graphic monitor and pointer (mouse) 
- It could be quicker to type commands rather than click buttons

##### Disadvantages
-   Users need to learn commands to use the software (harder for new users)

