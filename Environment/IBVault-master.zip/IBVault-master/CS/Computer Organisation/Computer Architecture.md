# Computer Architecture
#cs 


## Fetch-Decode-Execute Cycle
The fetch execute decode cycle is how computers carry out instructions. It is a cycle of fetching an instruction, decoding and understanding the instruction, then executing it, all of this one instruction at a time.

It consists for 3 main steps:

- Fetch

	- The address of the next instruction to be executed which is stored in the PC is sent to the main [[Memory]] through the MAB.

	- The main memory then copies the requested data onto a data bus which is sent back to the CPU.
- Decode
	- After an instruction is fetched, it is decoded by the CU

	- The decoded instruction could require extra data which would need to be fetched
	- If so, the CU would request data from the main memory through the MAB.
- Execute
	- After the instruction is decoded, the instruction is executed by sending out signals to components of the computer through the control bus. 

	- The cycle is repeated .

## CPU
The central processing unit (CPU) is responsible for fetching, decoding and executing instructions received from the main memory. The CPU is comprised of key components, each with a specific task to do. All activity in a computer generally goes through the CPU.

### Components of a CPU:
-  **Control Unit**:

	- The control unit (CU) is responsible for fetching/sending commands from/to the main memory and decoding it for the ALU to execute.

	- Functions of a CU:
		- Coordination of system operations

		-  Control and regulation of system operations

- **Arithmetic Logic Unit (ALU)**
	- The arithmetic logic unit (ALU) is responsible for mathematical operations performed by the CPU, such as:
		- [[Logic Gates]]
		- Mathematics
		- Comparison


## Buses
In order for the CPU to fetch/send instructions from/to the RAM, the data must be transported using buses which are sets of parallel wires connecting the components of a computer.

### Types of Bus:

- **Memory Address Bus **

	- The memory address bus (MAR) exists purely to communicate locations of data from the CPU to RAM (one directional).

		- For example, if the CPU wants to fetch a piece of data, it would send the address (memory location) of the data to the RAM through the MAR.

		-  The RAM would then get the data requested and send it to the CPU through the data bus.

- **Data Bus**
	- The data bus is used to transfer data between the CPU and RAM (bi-directional).

		- For example, if the CPU wants to fetch a piece of data, it would send the address of the data to RAM which would then return the data through the data bus.

- **Control Bus**
	- The control bus is used to communicate between components, it is used by the CPU to send instructions to the different components of a computer.

- **External Bus**
	- An external bus is a bus specifically used for external devices, it only allows for the data to be transmitted one way, from the CPU.

## Registers

- Registers are a form of storage which temporarily hold data or memory addresses which are currently being used by the CPU. 

- Registers are extremely fast, but extremely small and are embedded into the CPU.

### Types of Register:
- **Program Counter**

	- The program counter (PC) holds the address of the next instruction to be fetched by the CPU

	-  Every time an instruction is executed, the PC increments the instruction and stores the next instruction's address.

- **Current Instruction Register**
	- The current instruction register (CIR) stores the instruction currently being decoded by the CPU.

- **Memory Address Register**
	- The memory address register (MAR) holds the memory address (location) of the data to be fetched/written to in the next instruction.

- **Memory Data Register**
	- The memory data register (MDR) stores the data fetched from the main memory that will be used by the CPU in the next instruction.

- **Accumulator**
	- The accumulator (ACC) stores data currently being used by the ALU, such as numbers produced in calculations