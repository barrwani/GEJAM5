# Binary Representation
#cs #maths 
The Binary system goes up in terms of powers of 2, which is essentially to say $2^n$.
- Most Significant Bit (MSB) : The bit in a binary number which is of the greatest numerical value.
- Least Significant Bit (LSB) : The bit in a binary number which is of the lowest numerical value.
-  If the LSB is 1, the number is odd. Other wise, it is even.
We can represent numbers with decimal points using [[Fixed Point Representation]] and [[Floating Point Representation]] .

## Two's Compliment

- To store a negative denary number in binary, you must use Two's complement.
- Two's complement is when you make the MSB a negative number. The value of the MSB will tell you if the number is positive or negative.
- If we're looking at the Two's complement, the MSB must be zero for the final value to be positive. Otherwise it is a negative number.
- To get the negative value of a positive decimal integer, invert it's equivalent binary integer value and apply Two's complement to the MSB. You then add one to the number to get the final answer.


EG: 

To get from 5 to -5

```
8 4 2 1

0 1 0 1
```
1. Invert it and apply Two's Compliment to the MSB:

```
-8 4 2 1

 1 0 1 0
```
2. Which equals -6 in Denary. To get from -6 to -5, we must add one at the end
```
-8 4 2 1

 1 0 1 1
 ```

**Which gives us the final answer of -5.**


### Key Terms
- Signed – Negative numbers included

- Unsigned – No negative numbers included

- Both use the same number of bits.

- You will be told if it’s a signed number in the question.


