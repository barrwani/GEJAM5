# Floating Point Representation
#cs 

Floating point representation exists because we cannot represent every single decimal value with [[Fixed Point Representation]].

>Floating point numbers are **more hardware intensive** to generate and use as the process of creating them is more elaborate than fixed point numbers.


# Mantissa and Exponent 
   
A typical floating point number would consist of 2 parts, the mantissa and the exponent, the sizes of which will be given to you in the exam.

Think of the mantissa and exponent as the 'standard form' of [[Binary Representation]]. Below is an example in denary.
![Mantissa | 300](https://bournetocode.com/projects/AQA_A_Theory/pages/img/FPF.png)


In the case above, in order to get the final number that the standard form represents, we shift the decimal point of the mantissa to the right by 6 places.

 - If the exponent is a positive number, we shift right, thus making the final number bigger than the mantissa. 
 
 - If it is a negative, we shift left, making it smaller.

Below is a 6 digit mantissa and 4 digit exponent. 

```
0 1 1 0 1 0 | 1 1 0 1
```
The mantissa is a positive number, as the twos compliment (sign) bit is 0, and the exponent is negative, indicating a left shift.

$$0.11010 \times 2^{-3} = 0.00011010 $$

$$\frac 1{16} + \frac 1{32} + \frac 1{128} = \frac {13}{128}$$

   
> NOTE: If asked to convert to denary in an exam, the values will be a lot simpler than the example above.


