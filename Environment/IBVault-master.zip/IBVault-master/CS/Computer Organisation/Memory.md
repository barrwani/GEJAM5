# Memory
#cs 

## Primary Memory
Primary memory is the only memory directly accessible by the CPU, it is essentially used to store data and instructions for the CPU as machine code.

### RAM (Random Access Memory)
Random access memory (RAM) is a primary storage. It is used to store any data or instructions of applications currently being used by the computer to to be accessed by the CPU.

Properties of RAM:

- Can be read and written from

- Volatile (needs power for data storage)
- Very fast


### ROM (Read Only Memory)
Read only memory (ROM) is another type of primary storage. It is used to store data which shouldn't be modified such as the BIOS and bootstrap instructions.

ROM is soldered onto the motherboard and data is physically encoded into the ROM chip, making it extremely difficult to modify the data.

This is important because ROM holds important information required for a computer to turn on. Also, since the data is encoded into the chip, the data is non volatile.

Properties of ROM: 

- Read-only

- Non-Volatile
- Cannot be altered
- Stores bootstrap information

### Cache

- Cache is a from of RAM named 'static RAM' (SRAM).

- Cache is much faster than RAM but at the cost of being more expensive, because of this, cache is typically used in extremely small amounts.

- Cache is typically placed in between RAM and the CPU, it is used to store data that is actively being used and accessed most often by the system.

- When the CPU needs data it first checks if the data is stored in cache, if not the data is copied from RAM to cache so the CPU can access the data more quickly.

## Secondary Memory

### Persistent Storage

- Secondary memory is a form of storage that can written to (and most of the time read from) just like RAM.

- Unlike RAM, however, secondary memory is a persistent storage which means it is non volatile and can keep the data stored on it without power. 

- Secondary memory is also much slower than primary RAM, which is why they are (typically) cheaper and can have higher storage capacities. 

- Persistent storage is not only important to store user files permanently, but also to store instructions for the CPU when the system boots up. 

- Unlike RAM, the CPU cannot access secondary memory directly, the data from the secondary memory must be copied over to RAM so that CPU can access the data.

### Virtual Memory
- A major function of an operating system (OS) is resource management, which includes RAM. In a scenario where there is no available space left in RAM, the OS must find a way to manage this issue. 

- One method is through virtual memory, which is the OS's utilization of secondary memory as RAM.

- For example, if there is no space available in RAM, the OS could allocate space from the secondary memory to act as RAM, moving some data from RAM into the secondary memory.
