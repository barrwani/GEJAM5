# Data Transmission
#cs 

## Protocols

Protocols are a set of rules for data communication over a network

Without them, no information can be transmitted as computers don't know how to interpret the signals coming through the network


The essential functions of protocols:

- Ensuring data integrity
- Managing flow control
- Preventing **Deadlock**
- Managing Congestion
- Performing Error Checking

### Data Integrity
Data integrity, in the context of networking, refers to the overall completeness, accuracy and consistency of data. 

Data integrity must be imposed when sending data through a network.

![[Pasted image 20220407115301.png|400]]

### Flow Control
Flow control is the mechanism that ensures the rate at which a sender is transmitting is in proportion with the receiver’s receiving capabilities.

Flow control is utilized especially in cases where the sending device can send data much faster than the receiver can digest.

![[Pasted image 20220407115247.png|400]]
### Deadlock
A deadlock is a situation where two nodes or processes are trying to access the same node at exactly the same moment, causing neither to be able to proceed.

It is then up to the relevant protocol to stop both, and requeue them so that they can happen sequentially, letting traffic flow.

### Congestion Control
Congestion refers to a network state where a node or link carries so much data that it may deteriorate network service quality, resulting in queuing delay, frame or data packet loss and the blocking of new connections.

In modern networks, avoiding congestive collapse involves the application of network congestion avoidance techniques along with congestion control.

![[Pasted image 20220407115649.png|400]]

### Error Checking

Error checking or detection refers to the techniques used to detect noise or other impairments introduced into data while it is transmitted from source to destination. 

Error detection often makes use of parity bits, bits at the end of a packet that are calculated to be either a 1 or 0.

![[Pasted image 20220407115731.png|400]]


## Data packets
A packet is a small unit of data used in network communication.

A data packet is composed of a header and a payload.

The Header contains the addressing data and other data required to reach the intended destination.

The Payload is the actual data being transported by the packet.
The Payload is the only data that is received by the source and destination, as the header information is stripped from the packet when it reaches the destination.

![[Pasted image 20220407113746.png]]


## Packet Switching
Packet-switching describes the type of network in which relatively small units of data called packets are routed through a network based on the destination address contained within each packet