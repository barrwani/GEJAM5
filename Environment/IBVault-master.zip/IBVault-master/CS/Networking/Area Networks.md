# Area Networks (AN)
#cs 
Area Networks are networks confined within a certain geographic location.

## Local Area Network (LAN)

- A LAN connects network devices over a relatively short distance. 

- Network restricted by a geographical location


## Personal Area Network (PAN)
- A PAN is a computer network organised around an individual person.

- Bluetooth and Mobile Data are good examples

## Wireless Local Area Network (WLAN)
- A WLAN provides wireless network communication over short distances using radio or infrared signals instead of traditional network cabling. 

- WLAN is a type of LAN
- Mobile phones, laptops, game consoles

## Metropolitan Area Network (MAN)
- MANs are large networks in a large geographical area

- Across buildings or an entire city


## Wider Area Network (WAN)
- WAN spans a large physical distance

- The internet is the largest WAN, spanning the entire Earth
- Routers maintain a LAN and WAN address
- A WAN is a geographically dispersed collection of LANs. 
- Most WANs are not owned by an organisation






