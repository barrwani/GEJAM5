# Open Source Interconnection
#cs 

## The Seven Layers:

OSI is a model which standardises the process of telecommunication. It is a universal set of rules which allows for software and devices from different developers and manufacturers to communicate with each other.

```ad-note
color: 66,87,80

Memorise each layer and it's number! These will appear on the exam. (APTDNP, 'A Place The Needle Drop Picked')
```

Before OSI, devices were unable to communicate with each other on the same network if they were manufactured by different companies. 

#### ** 7: Application**
- End-user Layer
- HTTP
- Applications
- DNS

#### **6: Presentation**
- Encryption 
- Decryption
- File saving
	
####  **5: Session**
- API
- Sockets

#### **4: Transport**
- End-to-End Connections
- Assembles & Disassembles Packets and Checks for Errors

#### **3: Network**
-  [[Area Networks]]
-  [[IP Addresses]]
- [[Network Topology]]
- Routers

#### **2: Data Link**
- [[MAC Addresses]]
- Packets
	
#### **1: Physical**
- Cables
- Hubs
- Physical Equipment
