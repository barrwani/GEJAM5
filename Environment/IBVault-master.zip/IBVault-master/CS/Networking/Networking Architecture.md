# Networking Architecture
#cs 

## Types of Networks
![[Area Networks#Area Networks AN]]

## Internet
- The internet is a globally connected network system that uses the TCP/IP protocols to transmit data via various types of media. 

- The internet is a network of global exchanges – including private, public, business, academic and government networks – connected by wired, wireless and fiber-optic technologies.

## VPN
- Uses the internet to allow people to log into a network remotely and access its resources, but encrypts the connection to thwart eavesdroppers.


![[OSI 7-Layer Model#Open Source Interconnection]]