# Network Topology
#cs 

A network topology is a diagram of how devices are connected in a network.

## Bus Topology

A bus network is a a network where all devices on a network communicate through one shared medium (cable/router). This is most common with WiFi through radio waves.

This causes congestion because all devices are competing for network resources so, is inefficient. Though, it is very cheap to setup.

![|300](https://www.computerhope.com/jargon/b/bustopol.gif)

#### Advantages:
-   Easy to setup and and more computers to the network

-   Quick to setup

-   Cost-effective

#### Disadvantages:
-   It becomes difficult to troubleshoot network issues because everything is connected

-   The network becomes limited by cable length/radio wave range

-   If the cable/router is damaged, the entire network goes down

-   Low security; all the data is open to other computers on the network to see

-   Collisions: the congestion of data transmission. Because so many devices are sharing a single cable/router the network will experience congestion which will slow down the network.


## Star Topology
A star network has all devices connect individually to a central computer (normally a switch) through their own wires.

This is the most common type of network. It is typically found in home networks, and is the most reliable network type. 

![|200](https://www.computerhope.com/jargon/s/star.gif)
#### Advantages:
-   They perform well and are fast

-   Easy to setup

-   Easy to add more computers to a network

-   Failures on a connected device won't affect the network as a whole

-   Very little network collision

-   Good security

#### Disadvantages:
-   Expensive to install

-   More hardware is required (more cable and a switch)

## Ring Topology

A ring network is a network where data is transferred in one direction in a loop.

At any one point, only one computer can token access. The computer with token access has command of the network and is the only one able to send data.

![|200](https://www.computerhope.com/jargon/r/ring.gif)

#### Advantages:
-   The system is very secure because the devices know exactly where data is coming from at all times.

-   Data transfer is extremely quick because the data only flows in one direction, so there is not interference or congestion.

-   Data transfer is easy; no routing needs to be done, the computer with token access just needs to send the data to the next computer.

-   The network can't be access by outsider/malicious devices.

#### Disadvantages:

-   If any computer on the network fails, the ring will be broken and no data can be transferred

-   If there is a problem with the main cable or connection, the entire network goes down