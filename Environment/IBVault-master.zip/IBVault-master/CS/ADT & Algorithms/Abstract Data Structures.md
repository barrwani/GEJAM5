# Abstract Data Types
#cs

An Abstract Data Type is a type of object or class whose behaviour is defined by a set of values and instructions.


``` ad-quote
color: 66,87,80
.An abstract data type defines not only a data representation for objects of the type but also the set of operations that can be performed on objects of the type. 
Furthermore, the abstract data type can protect the data representation from direct access by other parts of the program.
```

ADT code is easier to understand and can be changed without changing the rest of the program.
