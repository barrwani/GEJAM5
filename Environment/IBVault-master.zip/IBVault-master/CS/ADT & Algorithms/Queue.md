# Queue
#cs 
A queue stores a group of elements in an order putting the first added item at the start of and the last added item at the end (first in, first out FIFO). 
 It is one of the [[Abstract Data Structures]].

### Methods

#### Variables

``` java
public static int[] array = new int[10]; // array is declared with a size of 10
public static int start = 0; // the start variable will point to the beginning of the queue (the item first in) 
public static int end = 0; // the end variable will point to the end of the queue (the last first in)
public static int count = 0; // this will keep track of the number of items in the queue
```

#### Full

The `isFull()` method checks if there is any available space in the queue, because if there isn't the `enqueue()` method won't work.

```java
public static boolean isFull() {

	if (count >= array.length) { // if the counter is greater than the length 
	// of the array, then the queue must be full
 		return true;
	} 
 	else {
 		return false;
	}
}
```

#### Empty
The `isEmpty()` method checks if there are any values in the queue, because if there aren't the `dequeue()` won't work.

``` java
public static boolean isEmpty() {
	if (count == 0) { // if the count is 0,
	//there must no be any items in the queue
		return true;
	} 
	else {
 		return false;
	}
}
```

#### Queue
The `queue()` adds an item to the queue, which means it will be the last item out.

```java
public static void enqueue(int value) {

	if (isFull()) { // checks if the array has any available space in the array

 		return; // if so, returns nothing, not queueing anything

 	}

	array[end] = value; // a new item is added to the end of the queue, 
	// set to the value inputted

	end++;

	count++; // end and count are both incremented 
	//because they have both increased

 	if (end >= array.length) { // a check is made to make sure that the queues 
	// end isn't over the max size of the array

		end = 0; // if it is, the end position is moved to index 0
	}
}
```

#### Dequeue 
The `dequeue()` method removes the first item from the queue.

``` java
public static void dequeue() { 
	if (isEmpty()) { // makes sure there is a value to dequeue 
		return; // if not, returns nothing, not dequeueing anything 
	} 
	array[start] = 0; // the first item in the queue is removed 
	start++; // the start header is incremented 
	count--; // the counter is lowered by 1 because there is one less element 
	if (start >= array.length) { // a check is made to make sure that 
	//the start isn't over the max size of the array 
		start = 0; // if it is, the start position is moved to index 0 
	} 
}

```