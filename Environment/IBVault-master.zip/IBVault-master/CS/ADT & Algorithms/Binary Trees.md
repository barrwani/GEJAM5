# Binary Trees
#cs 
A binary tree is an ADT ([[Abstract Data Structures]]) made of nodes, where each node contains a "left" pointer, a "right" pointer, and a data element. 

Not to be confused with [[Binary Representation]]. Binary in this case represents the fact that each node can only have 2 children.

The "root" pointer points to the topmost node in the tree. 

The left and right pointers recursively point to smaller "sub-trees" on either side. 

![Binary Tree](https://i2.wp.com/techsprobe.com/wp-content/uploads/2020/03/Untitled-1-2.jpg?fit=1011%2C356&ssl=1)

A null pointer is a pointer which does not lead to a new node.

A leaf node is a node with two null pointers.



```ad-note
title: NOTE
color: 66,87,80

“Binary trees will be examined at the level of diagrams and descriptions. Students are not expected to construct tree algorithms using pseudocode.” 

“Tracing and constructing algorithms are not expected.”
```

In exams, you will be asked to traverse binary trees using one of 3 methods:

## In-Order Traversal
1. Left
2. Root
3. Right

![|200](https://www.techiedelight.com/wp-content/uploads/Inorder-Traversal.png)
## Post-Order Traversal
1. Left
2. Right
3. Root

![|200](https://www.techiedelight.com/wp-content/uploads/Postorder-Traversal.png)

## Pre-Order Traversal
1. Root
2. Left
3. Right

![|200](https://www.techiedelight.com/wp-content/uploads/Preorder-Traversal.png)