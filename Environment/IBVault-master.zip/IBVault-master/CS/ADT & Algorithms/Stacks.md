# Stacks
#cs 

A stack stores a group of elements in an order putting the last added item at the start and the first added item at the end (first in, last out FILO).

It is useful to think of a stack as a stack of books.
The first book added to the stack will always be on the bottom and the last book added will be on the top.

In order to reach the first book added, you must remove every book on top of it (which is all the other books), so the first book is always the last book reached (FILO).

It is one of the [[Abstract Data Structures]]

## Methods 
#### Variables:
``` java
public static int[] array = new int[5]; 
public static int count = 0; // will keep track of the index of the newest item, and the number of items
```

#### Full:
Checks if the stack is full.

```java
public static boolean isFull() { 
	if (count >= array.length) { 
		return true;
	}
	else { 
		return false; 
	} 
}
```

#### Empty:

Checks if the stack is empty.

```java
public static boolean isEmpty() { 
	if (count == 0) { 
		return true; } 
	else { 
		return false; 
	} 
}
```

#### Push:

Adds a value to the top of the Stack.

```java
public static void push(int value) { 
	if (isFull()) { 
		return; 
	} 
	array[count] = value; 
	count++; 
}
```

### Pop:
Removes a value from the top of the Stack.

```java
public static void pop() { 
	if (isEmpty()) { 
		return; 
	} 
	count--; 
	array[count] = 0; 
}
```

