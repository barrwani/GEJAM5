# Linked List
#cs 
A linked list is made up of nodes containing both data and a pointer pointing to the next node. It is one of the [[Abstract Data Structures]].

![Linked List](https://www.notion.so/image/https%3A%2F%2Fs3.us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F62428ac6-8712-4835-8f7e-181eb0b8ba52%2FUntitled.png%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAT73L2G45O3KS52Y5%252F20211102%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20211102T061426Z%26X-Amz-Expires%3D86400%26X-Amz-Signature%3D15f54b0cbdf6c49d3ddccd2ddf4fb145afd257d68f5739c26a5e65ca5b65be72%26X-Amz-SignedHeaders%3Dhost?table=block&id=7b0399b0-e63c-4a5d-aa23-6af33f866724&cache=v2)

In an array, items can be accessed using an index, but in linked lists, you must follow the pointers of each node to access a wanted element.

```ad-note
color: 66,87,80
To traverse a linked list, you must start from the header node (first node) and follow each consecutive node's pointer to the next node.
```


## Null Pointers

- A null pointer is a node which contains nothing, no data or pointer, it represents the end of a node, and acts as an indication for a program to stop traversing a linked list.

## Circular Linked Lists

A circular linked list has no null pointer, but rather, at the end of the list, points back to the header node
![](https://www.notion.so/image/https%3A%2F%2Fs3.us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F554bf100-601f-4e8d-85bb-60be30109f2d%2FUntitled.png%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAT73L2G45O3KS52Y5%252F20211102%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20211102T061426Z%26X-Amz-Expires%3D86400%26X-Amz-Signature%3Dcf57b299998a5de989ec6bb8d7539e4819829732d7f30fb406b2c4897e8e4cb7%26X-Amz-SignedHeaders%3Dhost?table=block&id=74613547-84bc-453d-8333-370742affbf3&cache=v2)

This allows a programmer to traverse a linked list infinitely and start from any node if they wanted to.


## Inserting Elements 

1.  To insert a new node into a linked list, the list must be traversed to find the previous node to the location of insertion

2.  Once the previous node is found, the new node is created

3.  The previous node's pointer is then copied into the new node's pointer so that the new node points to what the previous node originally pointed to

4.  The previous node's pointer is changed to point to the new node instead


## Deleting Elements

1.  To delete a node in a linked list, the list must be traversed to find it's previous node

2.  The node's pointer is then copied to the previous node's pointer so that the previous node points to what the node being deleted originally pointed to

3.  The node is then deleted

## Modifying Elements

To modify a linked list element, the element can either:
- Be found through traversal then have its data modified

- Be found through traversal then create a new node and copy over the old node's pointer, then change the old node's previous' pointer to point to the new node.
