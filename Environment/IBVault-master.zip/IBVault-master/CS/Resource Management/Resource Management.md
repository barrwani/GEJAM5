# Resource Management
#cs 

## The role of the OS

The OS is the core of the system software and manages the computer resources like memory and IO devices.

The OS also provides an interface for users to interact with the computer. 

![[Pasted image 20220410113820.png|150]]

### CPU Scheduling

The OS manages all processes (Process Management) and sometimes a process needs to be interrupted, scheduled, queued, etc. 

This is called CPU scheduling, and it determines which process in memory is executed by the CPU at any given time.

This relates to **time sharing**, where multiple users, multitasking, multithreading, and multiprogramming all relate to the computer managing multiple users and processes at once. 

### Memory Management


