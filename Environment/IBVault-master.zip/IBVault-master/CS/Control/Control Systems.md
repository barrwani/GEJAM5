# Control Systems
#cs 


**Control Systems are automatic devices used to replace the need for human interaction for mundane tasks, such as opening a door, or for human safety, such as an air bag.**

Control Systems use a process known as **[[Input-Process-Output]] **cycles. The machine takes an input, processes it using arithmetic and logic then outputs an action.
   
-   A control system is a device which provides control for another system, and it works automatically. It does this in an automatic manner, without human intervention.

-   Control systems relieve/remove humans from repetitive, mundane tasks, such as opening a door. Car airbags work in a similar way, with the goal of making the device safer.

-   Control systems include sensors and feedback from the environment.

##  Transducers
A transducer can broadly be defined as any device which converts energy into one form into another.

```ad-note
title: NOTE
color:67,86,80

Input transducer -> Sensor
Output transducer -> Actuator

```

## Microprocessors
A microprocessor is just a small processor. It's an integrated circuit with all or most of the functions of a CPU. It's used during the processing of input data.

#### General Processor
A general purpose processor microprocessor has the ability to run a range of programs. The CPU in a PC is a general processor.

#### Embedded Controller
An embedded controller (or microcontroller) are small chips that have some elements of a larger system, such as RAM or ROM, but they operate on a small scale to perform small, precise tasks.

#### GPU
A graphics processing unit (GPU) is specialized in perform heavy mathematical problems very efficiently and quickly, this allows for quicker and more realistic graphics rendering.

## Sensors
Sensors are essential to a control system, they provide data to the microprocessor, allowing the actuators to respond properly.

There is an array of sensors suited for different situations.

Types of Sensors include:

-   Sound

-   Motion

-   Vibration

-   Optical/image

-   Active pixel sensor: used to capture digital images
-   Infrared sensor: used to capture infrared radiation energy

-   Pressure

-   Temperature

-   Proximity

## Ethics

Control Systems may raise ethical concerns, such as:

- Reliability
	- An unreliable system can lead to time loss, data loss, money loss, injuries or even death.

- Integrity
	- If a system lacks integrity, the data is inaccurate, incorrect or incomplete.
	- Leads to misinformation

- Inconsistency
	- If data in a system is inconsistent, this may cause confusion to the user.

- Security
	- Security is the protection of hardware and software from unauthorized access.

- Privacy
	- Privacy is the user's ability to control where their data goes and how it is used.

## Distributed & Centralised Systems

A centralized system has a dedicated computer system that is responsible for all computations required in order to run the control system.

A distributed system has multiple computer systems all performing parts of a calculation.

## Autonomous Agents

An autonomous agent is an entity, that performs tasks on behalf of its owner with minimal interference from the owner.

-   They have predefined algorithms supplied by the owner

-   They have artificial intelligence, so they can learn from their environment through their sensors

-   They require minimal interference from the owner


### Environments

The environment of an autonomous agent is very important. 

The complexity, unpredictability and accessibility of an environment will heavily influence how effective the autonomous agent is.

#### Accessibility
The accessibility of an environment refers to the autonomous agent's ability to collect whole and accurate data of its environment.

If an environment is too large for an autonomous agent's sensors to reach, then the environment is inaccessible.

#### Determinism 
The determinism of an environment refers to the autonomous agent's ability to determine the next state of the environment. 

A simple environment with minimal variables and complexities will be easy for an autonomous agent to determine

In a real world environment, there are thousands of variables such as humans, which are unpredictable, making it almost impossible for an autonomous agent to determine.

#### Static VS Dynamic

A static environment doesn't change (is static) while the autonomous agent is performing a task.

A dynamic environment can change while an autonomous agent is performing a task.

A static environment is much less complex and so easier for an autonomous agent to operate in.

