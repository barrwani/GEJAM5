# Input-Process-Output
#cs #business 

In the Input-Process-Output cycle for [[Control Systems]]:

-   An input is provided by the system from the real world.   

-   The input is processed using a form of arithmetic/ logic   

-   As a result of the process, an action is performed (output)   

-   This action can be monitored and measured by the control system via the available sensors. The actions may affect the input.

![IPO Cycle](https://technologystudent.com/images/consys1.gif)


The IPO cycle is the process we use to allow [[Control Systems]] to maintain themselves without requiring manual operation. In exams, you should be able to clearly outline the steps of the IPO in different contexts.


This process is also often used in organisations in business. 