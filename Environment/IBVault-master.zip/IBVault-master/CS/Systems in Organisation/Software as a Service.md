# Software as a Service (SaaS)
#cs 


## Advantages:
-   Subscription is paid monthly rather than all at once upfront, makes it more realistically affordable

-   Multiple devices can use the same subscription simultaneously

-   Applications can be updated easily, keeping the user up-to-date

## Disadvantages:

-   The user does not own the software, they are subscribing to it

-   The user needs a reliable internet connection

```ad-note 
color: 66,87,80

SaaS is rapidly replacing traditional software due to higher long term profits for organisations and lower up front costs for consumers. 
```