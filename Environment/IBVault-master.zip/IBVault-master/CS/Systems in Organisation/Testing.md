# Testing
#cs 

## Errors

- **Logical** Errors:
	- A logical error is a problem with the developer's logic; these typically don't cause crashing or errors in the program.
	- For example: when trying to find the area of a circle, the developer uses the incorrect formula.

- **Syntax** error
	- A syntax error is a typing error by the developer; it happens when the developer doesn't follow the programming language's rules.
	- For example: in Java the developer forgets to declare a variable.

- **Runtime** error
	- A runtime error is not the fault of the developer; it happens when something outside of the program goes wrong.
	- For example: loss of internet or electricity or the system runs out of storage or [[Memory]].


## Types of Testing
- **Unit** Testing

	- Checks small functions of a program to see if they work.
- **Integration** Testing
	- Ensures that separate parts of a program work together well.
- **System** testing
	- Ensures that the program works correctly on the end-users' systems.

	- EG: making sure the program works on Windows and macOS.
- **User Acceptance** Testing
	- Done before the software is made available to the general public. 

	- Normally named alpha and beta testing, they are done to make sure the program works well and to the user's standards.
	- Alpha testing is normally done within the organisation.
	- Beta testing is normally done by volunteering end-users. 
