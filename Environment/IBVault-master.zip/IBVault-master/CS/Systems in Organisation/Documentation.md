# Documentation
#cs 

## What is Documentation? 
- User documentation serves to explain the system to the end-user.

- It guides the user through the system
- It should be simple

``` ad-note
color: 66,87,80

It doesn't need a detailed explanation of the systems functions, since the user is usually a non-technical person. 

They need only to understand how to use the system.
```


## Typical Documentation Should Include:
-   Minimum hardware and software requirements
  
-   Installation guide
    
-   How to start the system
    
-   How to use different features of the system
    
-   Screenshots explaining main features of the system
    
-   Example inputs and outputs
    
-   Explanations of error messages and troubleshooting guides
    
-   Information to contact the developer of the system if an undocumented question arises