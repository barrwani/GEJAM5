# System Development Life Cycle (SDLC)
#cs 

 ## The steps of the SDLC are:
- Analysis
- Design
- Implementation
- Operation
- Maintenance

## Analysis
- This involves identifying the problem, finding the solution and outlining the requirements to complete the solution.

## Design
- Designing how the solution will be implemented.

## Implementation
- Implementing (programming) the solution into the product
- Creating the product itself.

## Operation
- Releasing the product/updates to the consumer. This will lead to identifying bugs and feature requests.
- [[Documentation]] to ensure they understand how to use the product.
- At this stage, organisations would choose whether to ship the product as [[Software as a Service]] or as traditional software.

## Maintenance
- Fixing the bugs and implementing new features
- [[Testing]] the product.
- Essentially starts the cycle again beginning with analysis.
