# Ethics
#cs 

## list of Social and Ethical Issues
(Use this list to help discuss social and ethical issues)
1.  Reliability
    
2.  Integrity
    
3.  Inconsistency
    
4.  Security
    
5.  Privacy
    
6.  Anonymity
    
7.  Intellectual property

8.  The Digital divide and Equality of Access
    
9.  Surveillance
    
10.  Globalization and cultural diversity
    
11.  IT policies
    
12.  Standards and protocols
    
13.  People and machines
    
14.  Digital Citizenship