# Change Management
#cs #business 

Change Management is defined as the approach an organisation takes to organisational change. Changes would include:

- Changes in Project Goals 
- Transitioning into providing a new product/service all together (End of [[System Development Life Cycle]])


## Types of change management:
- Big Bang
- Parallel
- Phased
- Pilot


## Big Bang:
- This is when the old system is abandoned or turned off and replaced with the new system all at once.

- Forcing employees to adapt to the new system would result in a period of inefficiency, but it allows for a faster transition

## Parallel:
- This is when the old system and new system operate at the same time for a period. This gives the user the option to use the old or new system.

- After a period, the old system is abandoned or turned off.

- This allows the developers to fix any issues with the new system and gives users the chance to get used to the new system.

- But there will be more operational costs for running two systems at once, and the developers will have more work managing two systems

- Employees would also be more attached to the system they are already used to.

## Phased:
- This is when features are slowly added/removed from the old system, incrementally updating the old system until it becomes the new system.

- This doesn't disrupt user productivity as much as big bang and allows the user to adjust to the new system more easily.
- Oftentimes you may find the employees remaining attached to the old system regardless.

## Pilot:
- This is when the new system is offered to a small group of users (pilot group) that test the new system

- Once the issues are ironed out, the new system is pushed to all users and the old system is abandoned.