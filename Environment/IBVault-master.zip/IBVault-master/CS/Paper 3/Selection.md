# Selection
#cs 

Selection is one of the main steps of the [[Genetic Algorithms]] process.

## Tournament Selection

Simplest selection type.

A subgroup is selected in a population, and the best individual in the subgroup is selected.

Each subgroup typically has 2 to 3 members.

Not possible to pick the lowest fitness individual.

## Roulette (Proportional) Selection

Every individual's fitness is assigned a probability and a 'roulette wheel is spun'. 

The higher the fitness the higher the probability and the more likely the fittest individual.

Double-Edged Sword, the diversity of the individuals will be eliminated if the same ones keep getting selected (premature convergence) , and there is a possibility that the lowest fitness individual is selected.

![|350](https://www.researchgate.net/profile/Alicia-Tang/publication/269841543/figure/fig1/AS:295073825738755@1447362490320/Roulette-wheel-selection-example.png)

## Stochastic Universal Sampling (SUS)

Alternative method to roulette selection.

The wheel is divided into N cutoffs with equal spacing.

Smooths out the elements of randomness which is present in roulette selection, ensures individuals are selected according to:
- **Many** good individuals
- **Some** average individuals
- **Few** bad individuals

Still has the possibility of not selecting the best individuals

![|350](https://www.oreilly.com/library/view/hands-on-genetic-algorithms/9781838557744/assets/3396c706-26cb-47b5-8b10-0d46d370a45f.png)

## Rank Selection

Same as Roulette Selection, but instead of assigning probabilities based on fitness, we rank the individuals based on their fitness and assign the probabilities more proportionally 

'Levels the playing field'

Ensures that even if an individual has the worst fitness score it still has a (somewhat low) chance of being selected,.

```ad-note
color: 66,87,80
It doesn't make any difference whether the fittest candidate is ten times fitter than the next fittest or 0.001% fitter. In both cases the selection probabilities would be the same.

All that matters is the ranking relative to other individuals.
```

![|350](https://miro.medium.com/max/1188/0*YaPjHE4PPMXi1ei3.png)

## Elite Selection

None of the other selection methods guarantee the selection of the best individual. 

The genes of the best individual can be very valuable for future generations, so this  is an approach which protects them.

It can be based off of another method, but the main change is that it guarantees inclusion of the best individuals in the selected population.