# Genetic Algorithms
#cs 

Genetic Algorithms are algorithms which are based off of Darwin's Theory of Evolution. 
It reflects the process of Natural [[Selection]] where the 'fittest' or best individuals are selected for reproduction.

It can be used for solving the [[Traveling Salesman Problem]] and for performing [[Marketing Mix]] analysis.

## Key terms:
- **Convergence**: Offspring varies little from parents

- **[[Crossover]] Operator**: The process which combines the characteristics of two solutions in order to generate a new solution.
- **Offspring**: The new solution produced when combining the characteristics of two previous solutions.
- **Computational Intractability**: A problem which is difficult or impossible for a computer to solve in a realistic time frame.
- **Combinatorial Optimisation**: Finding the most efficient/optimum tour from possible valid tours from a set of finite objects.
- Exploration: Searches for novel solutions in a wider global scale usually with mutation or crossover in hopes of finding even better solutions than the fit genes in the local set
- Exploitation: Searches for the best solutions only in the local scale using methods of selection
- **Problem Space**: The set of all possible solutions to problems.
- **Heuristic**: A trial and error approach to problem solving.
- **Hill Climbing**: An optimization algorithm which continually moves upwards until an optimal solution is found.
- **Novelty Search**: An alternative approach to selection which involves choosing different individuals rather than the best individuals. The goal here is to make every individual unique rather than to make them the 'most fit'. Goal based VS Novelty Based.
- **Population**: A group of solutions/individuals.
- **Elitism**: The strategy for selecting the best individuals to produce the next generation of individuals.
- **Chromosome**: A set of values or traits in an individual.
- **Gene**: A single trait or value in an individual.
- **Diversity**: The variance of individuals within a population.
- **Termination Condition**: The condition that should be met for us to end the GA process. 


## Process:


#### The GA process consists of 4 main steps:

- **Initialisation** of a random population of **individuals** (our mating pool)

	- In this function, we run a **fitness function** which determines how fit an individual is. 

	- Each individual is given a **fitness score**, where the higher the score, the better the solution, and the more likely it is to be selected.
- **[[Selection]]** of the best 2 best individuals (with highest fitness)
-  **[[Crossover]]** of the best two individuals to produce a new population
-  **[[Mutation|Mutating]]** our population with randomness

### Initialisation:
- The process starts with an initial set of individuals known as the population. If we think of this in terms of a problem, each individual is a solution to the problem we would like to solve. 

- Each individual is characterised by a set of parameters or variables known as **genes**. 
	- We combine genes into a string to form a **chromosome**.

```ad-example
color: 66,87,80
Below we have a population (set) of individuals $A_n$, each posessing their own unique set of **genes** (**chromosomes**). In this case, we are using [[Binary Representation]] to represent our individuals.

!["GA"| 300](https://miro.medium.com/max/1112/1*vIrsxg12DSltpdWoO561yA.png)
```
### [[Selection]]:
- [[Selection]] is a simple step. Here we would select our fittest individuals based on their fitness score and allow their genes to pass onto the next generation.

- The higher the fitness score, the higher the chances of being selected as a parent.

- There are many [[Selection]] types, some of which would be more complex than others.

### [[Crossover]]:
- In the [[Crossover]] phase, a ** [[Crossover]] point ** is chosen at random. 

- Our **offspring** or children are created by exchanging the parents genes until we reach our [[Crossover]] point.

### [[Mutation]]:
- In the [[Mutation]] step, some of the genes of each individual can be subjected to a random [[Mutation]]

	- In the case of the [[Binary Representation]] numbers we were using, it would be a bit flip.
- [[Mutation]] is done to maintain **diversity** in the population, and to prevent a premature **convergence**

``` ad-note
color: 66,87,80

Once the population has converged (the children produced do not vary from the previous generations significantly) We can **terminate** our GA. This is to say that our problem has been solved.
```

