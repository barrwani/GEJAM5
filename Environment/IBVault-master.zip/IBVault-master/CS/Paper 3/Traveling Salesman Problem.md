# Traveling Salesman Problem
#cs 

The traveling salesman problem is an NP-hard problem which asks:

```ad-quote
color: 66,87,80

Given a list of cities and the distances between each pair of cities, what is the shortest possible route that visits each city exactly once and returns to the origin city?
```
