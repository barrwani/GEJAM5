# Crossover 
#cs 
Crossover is a step in the [[Genetic Algorithms]] process. 

There are several types of **crossover operators**.

## Single-Point Crossover
Where one crossover point is chosen at random. Everything to the right side of the crossover point will be swapped, resulting in two offspring.

## **Two-Point Crossover**
Where two crossover points are chosen at random. Everything in between the two crossover points will be swapped.

Equivalent to performing two Single-point Crossovers. 

**N-Point Crossover** would be a generalisation of this method, where we would choose N crossover points.

## **Uniform Crossover**
Where everything is swapped at random with equal probability, resulting in unequal inheritance from offspring to offspring.

 !["Crossover" | 300](https://www.researchgate.net/profile/Ahmed-El-Shouny/publication/338574968/figure/fig1/AS:847224200232960@1579005398161/llustration-of-one-point-two-point-and-uniform-crossover-operators-Mutation.ppm)


## Linear Combination Crossover

Linear combination crossover is the example of a crossover without any randomness. 

A child's genes are a simple linear combination of it's parent's genes.

![|350](Images/LinearCrossover.png)

## **Blend Crossover**

Blend crossover method chooses random genes in the range defined by parent genes.

![|350](Images/BlendCrossover.png)

The children can be a set amount off of the parents' genes.

## Order Crossover

Order crossover is used for ordered genes

The main principle in this approach is to preserve the order of parent genes

![|350](Images/OrderCrossover.png)

## Partially Mapped Crossover
In Partially Mapped Crossover, similar to ordered crossover, order of a segment is preserved.

The remaining genes locations are dictated by a gene mapping relationship.

![[Pasted image 20220505182112.png|400]]

## Cycle Crossover
In Cycle Crossover, a cycle is determined defined by the parents. The location of the genes contained in this cycle are preserved, and all other genes are copied from the other parent.

![[Pasted image 20220505184224.png|400]]


##  Fitness Driven Crossover
Fitness driven crossover is an approach that compares the child to the parent and selects the best one. 

The main principle of this approach is that children should be better than their parents or not exist at all.

![|350](Images/FitnessDrivenCrossover.png)