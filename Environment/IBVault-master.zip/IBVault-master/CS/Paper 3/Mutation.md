# Mutation
#cs 
A step in the [[Genetic Algorithms]] process. 

## Random Deviation Mutation

 A random variable is added to the gene with a certain probability.

![|350](Images/RandomDeviationMutation.png)
## Exchange Mutation
Mutation exchange is mainly applied to a **[[Binary Representation]] or ordered** set of genes.

A pair of genes are exchanged from randomly selected positions.
 
 ![|350](Images/ExchangeMutation.png)
## Shift Mutation
Shift Mutation is moving a gene from a randomly selected position by a random number of positions to the left or right.

The content of all intermediate genes is shifted by one position. 

This mutation method is applied to a ***binary or ordered*** set of genes.

![|350](Images/ShiftMutation.png)

## Bit Flip Mutation

Applied to **binary gene sets**

A random gene is selected, and bit flipping is provoked from 1 to 0 or from 0 to 1

![|350](Images/BitFlipMutation.png)

## Inversion Mutation
Picks a random subrange and changes the order of the values in it. 

This mutation method is applied to a **binary or ordered **set of genes

![|350](Images/InversionMutation.png)

## Shuffle Mutation
Shuffle mutation, like inversion mutation, picks a random subrange, but instead of changing the order of the values in it, it just shuffles the values.

![|350](Images/ShuffleMutation.png)

## Fitness Driven Mutation
Fitness driven mutation, like the Fitness Driven [[Crossover]], is an approach that is trying to obtain only positive changes.

We run several mutations and pick the best one; if all mutations are worse than the original individual, then we leave the original without a mutation.

![|350](Images/FitnessDrivenMutation.png)