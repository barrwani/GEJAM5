# Lenstra-Lenstra-Lovász (LLL)
#cs #maths #cysec 

## Lattice Reduction

Lattice reduction is classified as a series of algorithms and techniques which seek to find a good set of basis [[Vectors|vectors]] when given a bad set of basis vectors. 

Lattice Reduction attacks are the most common forms of [[Lattice-Based Cryptography]] attacks for [[NTRUEncrypt|Shortest Vector Problem ]] cryptosystems. 

In LLL, we start with a value k and our basis vectors. While k is not equal to the number of vectors (equal to N dimensions of our Lattice )

## Gram-Schmidt Vectors & Coefficients

We begin by finding the Gram-Schmidt vectors of the basis vectors.

The Gram-Schmidt process is a standard function that is used to produce a set of orthogonal vectors when given (assumed) non-orthogonal vectors. 

A fundamental component of GS vectors is the use of the [[Vectors|vector]] projection equation.

```ad-note
title:GS Process
color: 66,87,80


$$u_0 = b_0$$

$$u_1 = b_1 - \frac{b_1 . u_0}{|u_0|^2} u_0$$


```
## Size Condition

```ad-note
title: The Condition 
color: 66,87,80


$$|\mu_{k,i}| \leq 0.5$$
```
          
If this condition is met, the magnitude of the LLL-reduced basis vectors is guaranteed to have been reduced.

Should the condition not be met, we would readjust our basis vectors by calculating:

```ad-note
title:Condition  NOT Met:
color: 66,87,80


$$b_k = b_k - b_i(\mu_{k,i})$$

```

## Lovász Condition

```ad-note
title: The Condition
color: 66,87,80

$$| \mu_k|^2 \geq (\delta - \mu_{k, k-1})^2 \cdot |\mu_{k-1}|^2$$
```


The Lovász Condition is met when our Gram-Schmidt bases are orthogonal. 

The Gram-Schmidt coefficient $\mu_{k, k-1}$ will measure the angle between $u_k$ and $u_{k-1}$, and if the coefficient is near 0, the angle is near orthogonal.

```ad-note
title:Condition NOT Met
color: 66,87,80

Should the condition not be met, we would swap the values of $b_k$ and	$b_{k-1}$. 

Because we have changed our basis vectors, we must then recalculate our Gram-Schmidt vectors.

We then check for the Size Condition once more.
```

The value δ (delta) is simply a number between ¼ and 1 and is completely arbitrary if it’s within the range. 

We can guarantee that if our δ is within this range, our basis will be LLL reduced. For our calculations we will be using ¾, as that is the value that is most often chosen.

Once the Lovász Condition has been met, we can guarantee that our Size Condition has also been met. We increment k and move onto the next basis vector pair. 


## Uses

- Mathematical proofs
- Lattice Based Cryptography attacks
- Detection algorithms
- Cryptanalysis 