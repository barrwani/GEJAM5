# Happiness Markov Chain
#cs #kogiito 

A Markov Chain is a [[Conditional Probability]] model. 

